// Prumo ERP - Extensão (Resumo + Lançar pedido)
(function () {
    "use strict";

    const APP_URL = "https://TKadachii.github.io/prumo-erp/";
    const host = location.hostname || "";

    // 🤖 WhatsApp Web: dispara a campanha sozinho (vem antes dos outros hosts porque
    // esta função usa `return` pra encerrar o bloco assim que reconhece a página).
    // ⚠️ só no frame de cima: o manifesto usa all_frames, e sem essa trava cada iframe do
    // WhatsApp montaria o próprio painel e disputaria o mesmo envio.
    if (host.indexOf("web.whatsapp.com") !== -1) {
        if (window.top === window.self) iniciarZapAuto();
        return;
    }

    // ========= PONTE: roda na página do APP (github.io) =========
    if (host.indexOf("github.io") !== -1) {
        // 📥 Se tem uma Tabela de Preços pendente (lida no SPAmov, guardada no chrome.storage pra
        // não estourar o tamanho da URL), entrega ela pro app agora e limpa — só uma vez.
        try {
            chrome.storage.local.get(["friganso_tabela_pendente"], function (r) {
                const pend = r && r.friganso_tabela_pendente;
                if (!pend || !pend.produtos || !pend.produtos.length) return;
                if (Date.now() - (pend.ts || 0) > 10 * 60 * 1000) { chrome.storage.local.remove("friganso_tabela_pendente"); return; } // expira em 10min
                chrome.storage.local.remove("friganso_tabela_pendente");
                try { window.postMessage({ source: "friganso-ext", type: "TABELA_PENDENTE", produtos: pend.produtos }, "*"); } catch (e) {}
            });
        } catch (e) {}
        // 📊 Mesma ponte, pro Relatório de Vendas (pedidos reais lidos do SPAmov, com peso embarcado e
        // faturado de verdade — não é estimativa).
        try {
            chrome.storage.local.get(["friganso_relatorio_vendas_pendente"], function (r) {
                const pend = r && r.friganso_relatorio_vendas_pendente;
                if (!pend || !pend.pedidos || !pend.pedidos.length) return;
                if (Date.now() - (pend.ts || 0) > 10 * 60 * 1000) { chrome.storage.local.remove("friganso_relatorio_vendas_pendente"); return; }
                chrome.storage.local.remove("friganso_relatorio_vendas_pendente");
                try { window.postMessage({ source: "friganso-ext", type: "RELATORIO_VENDAS_PENDENTE", pedidos: pend.pedidos }, "*"); } catch (e) {}
            });
        } catch (e) {}
        // 📋 Mesma ponte, pra FILA de pedidos lida no SPAmov (vários pedidos de uma vez).
        try {
            chrome.storage.local.get(["friganso_fila_pendente"], function (r) {
                const pend = r && r.friganso_fila_pendente;
                if (!pend || !pend.pedidos || !pend.pedidos.length) return;
                if (Date.now() - (pend.ts || 0) > 60 * 60 * 1000) { chrome.storage.local.remove("friganso_fila_pendente"); return; } // fila dura 1h
                chrome.storage.local.remove("friganso_fila_pendente");
                try { window.postMessage({ source: "friganso-ext", type: "FILA_PENDENTE", pedidos: pend.pedidos }, "*"); } catch (e) {}
            });
        } catch (e) {}
        // 👥 Mesma ponte, pro cadastro de clientes lido da tela "Procura de Pessoas".
        try {
            chrome.storage.local.get(["friganso_clientes_pendente"], function (r) {
                const pend = r && r.friganso_clientes_pendente;
                if (!pend || !pend.clientes || !pend.clientes.length) return;
                if (Date.now() - (pend.ts || 0) > 10 * 60 * 1000) { chrome.storage.local.remove("friganso_clientes_pendente"); return; }
                chrome.storage.local.remove("friganso_clientes_pendente");
                try { window.postMessage({ source: "friganso-ext", type: "CLIENTES_PENDENTE", clientes: pend.clientes }, "*"); } catch (e) {}
            });
        } catch (e) {}
        // 💲 Preços lidos numa conferência. A carga fica no storage porque atravessar todos os itens
        // pela URL é frágil, principalmente em conexão móvel.
        try {
            chrome.storage.local.get(["friganso_precos_conferidos_pendente"], function (r) {
                const pend = r && r.friganso_precos_conferidos_pendente;
                if (!pend || ((!pend.itens || !pend.itens.length) && (!pend.excluidos || !pend.excluidos.length))) return;
                if (Date.now() - (pend.ts || 0) > 60 * 60 * 1000) { chrome.storage.local.remove("friganso_precos_conferidos_pendente"); return; }
                chrome.storage.local.remove("friganso_precos_conferidos_pendente");
                try { window.postMessage({ source: "friganso-ext", type: "PRECOS_CONFERIDOS_PENDENTE", itens: pend.itens || [], excluidos: pend.excluidos || [], cliente: pend.cliente || "" }, "*"); } catch (e) {}
            });
        } catch (e) {}
        window.addEventListener("message", function (e) {
            const d = e.data;
            if (!d || d.source !== "friganso-app") return;
            // 🤖 Campanha de WhatsApp: o site manda a lista pronta e a extensão guarda. Quem
            // consome é o content.js rodando no web.whatsapp.com. Responde ZAP_CAMPANHA_OK pro
            // site saber que a extensão existe E está viva (sem isso ele abriria o WhatsApp à toa).
            if (d.type === "ZAP_CAMPANHA" && Array.isArray(d.itens)) {
                try {
                    chrome.storage.local.set({
                        friganso_zap_campanha: {
                            itens: d.itens.map(function (i) { return { telefone: i.telefone, nome: i.nome, mensagem: i.mensagem, status: "" }; }),
                            idx: 0, rodando: false, respiro: d.respiro || 8, ts: Date.now()
                        }
                    }, function () { try { window.postMessage({ source: "friganso-ext", type: "ZAP_CAMPANHA_OK", total: d.itens.length }, "*"); } catch (e) {} });
                } catch (err) {}
                return;
            }
            if (d.type === "SET_CREDS") {
                try { chrome.storage.local.set({ friganso_creds: { usuario: d.usuario || "", senha: d.senha || "", autoLogin: !!d.autoLogin, irVendas: !!d.irVendas } }); } catch (err) {}
                return;
            }
            // 📋 A tela de Fila PEDE a fila em vez de só esperar. Duas situações resolvidas de uma vez:
            //  1. o usuário somou pedidos mas não tocou em "Finalizar" — a fila ficou aqui parada, e
            //     agora ele consegue puxar do próprio app;
            //  2. corrida de tempo: a tela montava antes da entrega automática chegar e via fila vazia.
            if (d.type === "PEDIR_FILA") {
                try {
                    chrome.storage.local.get(["friganso_fila_pendente", "friganso_fila_pedidos"], function (r) {
                        let pedidos = [];
                        const pend = r && r.friganso_fila_pendente;
                        if (pend && pend.pedidos && pend.pedidos.length) pedidos = pend.pedidos;
                        else {
                            const fila = (r && r.friganso_fila_pedidos) || [];
                            pedidos = fila.map(function (x) { return x && x.pedido; }).filter(Boolean);
                        }
                        if (!pedidos.length) { try { window.postMessage({ source: "friganso-ext", type: "FILA_VAZIA" }, "*"); } catch (e2) {} return; }
                        chrome.storage.local.remove(["friganso_fila_pendente", "friganso_fila_pedidos"]);
                        try { window.postMessage({ source: "friganso-ext", type: "FILA_PENDENTE", pedidos: pedidos }, "*"); } catch (e2) {}
                    });
                } catch (err) {}
                return;
            }
            // ⚡ TUDO automático: guarda credenciais (login + ir pra vendas) + pedido pendente
            if (d.type === "LANCAR_AUTO" && d.pedido) {
                try {
                    chrome.storage.local.set({
                        friganso_creds: { usuario: d.usuario || "", senha: d.senha || "", autoLogin: true, irVendas: true },
                        friganso_run_auto: { pedido: d.pedido, ts: Date.now() }
                    }, function () { try { window.postMessage({ source: "friganso-ext", type: "AUTO_SAVED" }, "*"); } catch (e) {} });
                } catch (err) {}
                return;
            }
            // 🔎 Conferência em lote: usa o mesmo robô de Fazer Pedido, mas guarda um marcador próprio.
            // Ao terminar de colocar os itens, NÃO confirma o pedido: libera o botão que lê os valores.
            if (d.type === "CONFERIR_PRECOS_AUTO" && d.pedido) {
                try {
                    const pedido = Object.assign({}, d.pedido, { conferenciaPrecos: true });
                    chrome.storage.local.set({
                        friganso_creds: { usuario: d.usuario || "", senha: d.senha || "", autoLogin: true, irVendas: true },
                        friganso_conferencia_ativa: { pedido: pedido, cliente: pedido.cliente || "", pronto: false, ts: Date.now() },
                        friganso_run_auto: { pedido: pedido, ts: Date.now() }
                    }, function () { try { window.postMessage({ source: "friganso-ext", type: "CONFERENCIA_SAVED" }, "*"); } catch (e) {} });
                } catch (err) {}
                return;
            }
            let novos = [];
            if (d.type === "LANCAR_PEDIDO" && d.pedido) novos = [d.pedido];
            else if (d.type === "LANCAR_VARIOS" && Array.isArray(d.pedidos)) novos = d.pedidos;
            else return;
            try {
                chrome.storage.local.get(["friganso_fila"], function (r) {
                    const fila = (r && r.friganso_fila) || [];
                    novos.forEach(function (p, i) {
                        fila.push({ id: Date.now() + "_" + i + "_" + Math.floor(Math.random() * 100000), cliente: p.cliente, itens: p.itens, ts: Date.now() });
                    });
                    while (fila.length > 30) fila.shift(); // guarda os últimos 30
                    chrome.storage.local.set({ friganso_fila: fila });
                });
            } catch (err) { /* ignore */ }
        });
        return;
    }

    // ========= SPAMOV: leitura + lançamento =========
    if (host.indexOf("friganso.com.br") === -1) return;

    // 📱 Força largura "de PC" no SPAmov mesmo no celular (no modo mobile a página
    // se espreme e o robô erra a posição dos campos). Roda no documento principal.
    if (window.top === window.self) {
        try {
            var vpFg = document.querySelector('meta[name="viewport"]');
            if (!vpFg) { vpFg = document.createElement("meta"); vpFg.setAttribute("name", "viewport"); (document.head || document.documentElement).appendChild(vpFg); }
            vpFg.setAttribute("content", "width=1280");
        } catch (e) {}
    }

    if (!document.body || document.body.tagName === "FRAMESET") return;

    const sleep = (ms) => new Promise(r => setTimeout(r, ms));
    // Texto da página SEM a faixa de status do próprio robô. Ela fica dentro do <body>, então
    // "o texto mudou" disparava com a nossa própria mensagem ("Buscando o nome do cliente...") e o
    // robô seguia antes do SPAmov achar o cliente.
    const bodyText = () => {
        const t = (document.body && document.body.innerText) || "";
        const sb = document.getElementById("friganso-status");
        const st = sb && sb.innerText;
        return st ? t.split(st).join("") : t;
    };

    // ---------- LEITURA (Resumo) ----------
    function extrairCliente() {
        const body = bodyText();
        let m = body.match(/CLIENTE[\s\S]{0,60}?\[[jf]\]\s*(\d+[a-z]?)\s*-\s*([^\n\r]+)/i);
        if (!m) {
            const re = /\[[jf]\]\s*(\d+[a-z]?)\s*-\s*([^\n\r]{3,})/ig;
            let mm, melhor = null;
            while ((mm = re.exec(body)) !== null) { if (mm[1] !== "0" && /[A-Za-zÀ-Ú]/.test(mm[2])) melhor = mm; }
            m = melhor;
        }
        return m ? { code: m[1].trim(), nome: m[2].trim() } : { code: "", nome: "" };
    }
    function extrairSpamov() {
        const t = bodyText();
        // número LOGO após o rótulo "SPAmov" (mais preciso; evita pegar limite de crédito/data por engano)
        let m = t.match(/SPAmov\s*(?:n[ºo°.]?\s*|:|-|nº|n°)?\s*(\d{6,8})\b/i);
        if (!m) m = t.match(/SPAmov[\s\S]{0,90}?(\d{6,8})/i); // fallback mais curto que antes (era 200)
        return m ? m[1] : "";
    }
    function extrairOrcamento() { const m = bodyText().match(/Or[çc]amento[\s\S]{0,40}?(\d{6,8})/i); return m ? m[1] : ""; }

    function acharTabelaItens() {
        const tables = document.querySelectorAll("table");
        for (let i = 0; i < tables.length; i++) {
            const txt = (tables[i].innerText || "").toLowerCase();
            if (txt.indexOf("valor unit") !== -1 || txt.indexOf("quant. mov") !== -1) return tables[i];
        }
        return null;
    }
    // 🎯 Acha o X (centro) do CABEÇALHO de uma coluna. O SPAmov aninha tabelas, então existe um <td>
    // container GIGANTE cujo texto contém vários títulos juntos ("...Valor Unit... P.Liq.(KG)...").
    // Por isso pegamos a célula MAIS ESPECÍFICA (texto normalizado mais curto) que casa — assim achamos
    // a célula real do título (ex: "P.Liq.(KG)" em x=1516) e não o container largo (centro ~960).
    // Busca também em <b>/<div> porque às vezes o título não é um <td> direto.
    function colXHeader(scope, teste) {
        const cs = (scope || document).querySelectorAll("td, th, b, div, span, font, nobr");
        let best = null, bestLen = 1e9;
        for (let i = 0; i < cs.length; i++) {
            const t = (cs[i].innerText || cs[i].textContent || "").toLowerCase().replace(/\s+/g, " ").trim();
            if (!t || t.length > 26) continue;            // ignora containers (texto longo) e vazios
            if (!teste(t)) continue;
            const r = cs[i].getBoundingClientRect(); if (!r.width || !r.height) continue;
            if (t.length < bestLen) { bestLen = t.length; best = r.left + r.width / 2; }
        }
        return best;
    }
    function colXQuant(scope) { return colXHeader(scope, function (t) { return t.indexOf("quant") !== -1 && t.indexOf("mov") !== -1; }); }
    // 🟡 Coluna "P.Liq.(KG)" — peso líquido do item, usado pra calcular o Valor da Nota = peso × preço
    function colXPLiq(scope) { return colXHeader(scope, function (t) { return t.indexOf("p.liq") !== -1 || t.indexOf("pliq") !== -1 || (t.indexOf("liq") !== -1 && t.indexOf("kg") !== -1); }); }
    // 💲 Coluna "Valor Unit." — preço por kg que o SPAmov usa (ex: "23,40/PL")
    function colXValor(scope) { return colXHeader(scope, function (t) { return t.indexOf("valor") !== -1 && t.indexOf("unit") !== -1; }); }
    // Converte "80.00" / "80,00" / "1.250,50" -> número (mesma lógica do parsePrice do site)
    // 🔢 Lê número escrito em português OU em inglês. Aceita "23,00", "23.00", "5.100,00",
    // "1,234.56", "278,8000" e "12941.8".
    //
    // ⚠️ BUG CORRIGIDO EM 2026-08-13 — leia antes de "simplificar" isto:
    // a versão antiga usava a regex  /-?\d{1,3}(?:[.,]\d{3})*(?:[.,]\d+)?|.../  e ela TRUNCAVA
    // qualquer número acima de 999,99 escrito com PONTO decimal. Em "5100.00" o \d{1,3} pegava
    // "510", esperava um separador, encontrava "0" e parava ali → devolvia 510.
    // Efeito real: o pallet de arroz (produto 29741) entrava na tabela a R$ 510,00 em vez de
    // R$ 5.100,00, e os 9 preços dele saíam todos truncados (5176.50→517, 5253.00→525...).
    // Passava despercebido porque preço de até R$ 999,99 funciona — e é a esmagadora maioria.
    function parseNumBR(s) {
        const m = String(s || "").trim().match(/-?\d[\d.,]*/);
        if (!m) return null;
        let x = m[0].replace(/[.,]+$/, "");          // separador solto no fim não conta
        const ultPonto = x.lastIndexOf("."), ultVirgula = x.lastIndexOf(",");
        const sep = Math.max(ultPonto, ultVirgula);
        if (sep < 0) { const v0 = parseFloat(x); return isNaN(v0) ? null : v0; }

        const casasDepois = x.length - sep - 1;
        const soUmTipo = (ultPonto === -1) !== (ultVirgula === -1);
        const apareceUmaVez = x.split(x[sep]).length === 2;
        // Com os dois separadores, o ÚLTIMO é sempre o decimal ("5.100,00" e "1,234.56").
        // Com um tipo só aparecendo uma vez: 3 casas depois = separador de MILHAR ("5.100" = 5100);
        // qualquer outra quantidade = decimal ("5100.00" = 5100,00 e "278,8000" = 278,8).
        const ehMilhar = soUmTipo && apareceUmaVez && casasDepois === 3;
        const ehTodosMilhar = soUmTipo && !apareceUmaVez;   // "1.234.567"
        if (ehMilhar || ehTodosMilhar) x = x.replace(/[.,]/g, "");
        else x = x.slice(0, sep).replace(/[.,]/g, "") + "." + x.slice(sep + 1);
        const v = parseFloat(x); return isNaN(v) ? null : v;
    }

    function extrairItens(spamov) {
        const raw = [];
        const ignorar = new Set([spamov, extrairOrcamento()].filter(Boolean));
        // 🛑 SÓ extrai itens se achar de verdade a tabela de um PEDIDO (com a coluna "Quant. Mov.").
        // Sem isso, telas que NÃO são pedido (ex.: Lista de Preços — catálogo inteiro, cada linha
        // "código + nome" igual a um item) eram lidas por engano como se fossem os itens do pedido.
        const tabelaAchada = acharTabelaItens();
        if (!tabelaAchada || colXQuant(tabelaAchada) === null) return [];
        const scope = tabelaAchada;
        const colX = colXQuant(scope);
        // 🟡💲 colunas de peso e preço: procura no escopo da tabela e, se não achar, no documento inteiro
        // (o cabeçalho às vezes fica numa tabela "irmã", fora da tabela de itens).
        const colXP = colXPLiq(scope) || colXPLiq(document);
        const colXV = colXValor(scope) || colXValor(document);
        const campos = [];
        scope.querySelectorAll("input").forEach(function (inp) {
            const tipo = (inp.type || "").toLowerCase();
            if (["checkbox", "radio", "hidden", "button", "submit", "image"].indexOf(tipo) !== -1) return;
            const v = (inp.value || "").trim();
            if (!/^\d+$/.test(v) || parseInt(v, 10) <= 0) return;
            const r = inp.getBoundingClientRect(); if (!r.width || !r.height) return;
            campos.push({ val: parseInt(v, 10), x: r.left + r.width / 2, y: r.top + r.height / 2 });
        });

        // ⚖️💲 Candidatos a PESO (P.Liq.) e PREÇO (Valor Unit.): podem ser <input> (readonly) OU texto numa célula.
        // Guardamos valor + posição na tela pra casar depois por COLUNA (X) e LINHA (Y) — bem mais robusto que
        // depender de o número estar num <td> direto da mesma <tr>.
        const numeros = []; // {val, x, y, dec}  (dec = tem casa decimal -> mais provável ser peso/preço)
        function addNumCand(s, el) {
            const txt = String(s || "").trim();
            if (!/\d/.test(txt) || txt.length > 16) return;
            // aceita "80.00", "23,40", "23,40/PL", "1.250,50"; rejeita coisas tipo "100000016129" (>9 dígitos colados)
            if (/^\d{10,}$/.test(txt.replace(/\D/g, "")) && !/[.,]/.test(txt)) return;
            const v = parseNumBR(txt); if (v === null || v <= 0) return;
            const r = el.getBoundingClientRect(); if (!r.width || !r.height) return;
            numeros.push({ val: v, x: r.left + r.width / 2, y: r.top + r.height / 2, dec: /[.,]\d{1,2}\b/.test(txt) });
        }
        document.querySelectorAll("input").forEach(function (inp) {
            const t = (inp.type || "").toLowerCase();
            if (["checkbox", "radio", "hidden", "button", "submit", "image"].indexOf(t) !== -1) return;
            addNumCand(inp.value, inp);
        });
        // 🔎 Varre QUALQUER elemento-folha com texto (SPAmov é antigo: usa div/font/nobr, não só td).
        document.querySelectorAll("td, th, span, font, b, div, a, p, label, i, small, strong, em, nobr, li").forEach(function (el) {
            if (el.children && el.children.length) return; // só folhas (evita pegar texto de containers)
            addNumCand(el.innerText || el.textContent || "", el);
        });
        // acha o número mais próximo de uma coluna (X) na linha do produto (Y), priorizando os com casa decimal
        function acharNaColuna(colXref, prodY, tolX, tolY) {
            if (colXref === null) return 0;
            const cand = numeros.filter(function (n) { return Math.abs(n.y - prodY) <= (tolY || 20) && Math.abs(n.x - colXref) <= (tolX || 70); });
            cand.sort(function (a, b) { if (a.dec !== b.dec) return a.dec ? -1 : 1; return Math.abs(a.x - colXref) - Math.abs(b.x - colXref); });
            return cand.length ? cand[0].val : 0;
        }
        try { dlog('🔎 peso/preço: colXP=' + colXP + ' colXV=' + colXV + ' candidatos=' + numeros.length); } catch (e) { try { console.log('[FRIG-LER] colXP=' + colXP + ' colXV=' + colXV + ' candidatos=' + numeros.length); } catch (e2) {} }

        scope.querySelectorAll("tr").forEach(function (row) {
            const cells = row.querySelectorAll("td"); if (!cells.length) return;
            let rawCode = "", codeCell = null;
            for (let i = 0; i < cells.length; i++) { const ct = (cells[i].innerText || "").trim(); const mm = ct.match(/^(\d{3,7})$/); if (mm) { rawCode = mm[1]; codeCell = cells[i]; break; } }
            if (!rawCode || ignorar.has(rawCode)) return;
            let nome = "";
            cells.forEach(function (c) { const ct = (c.innerText || "").replace(/\s+/g, " ").trim(); if (/[A-Za-zÀ-Ú]{4,}/.test(ct) && ct.length > nome.length) nome = ct; });
            if (!nome || nome.replace(/[^A-Za-zÀ-Ú]/g, "").length < 4) return;
            // 🚯 rejeita "nome" que na verdade é lixo de script/URL da página (não é produto)
            if (nome.length > 70 || /[{}=;]|\bfunction\b|document\.|\.ajax|https?:|frm_|spa_|timezone|getTimezone|var\s|css\(|position\(|\.hide\(/i.test(nome)) return;
            const rr = (codeCell || row).getBoundingClientRect(); const prodY = rr.top + rr.height / 2;
            let qty = null, melhor = 1e9;
            campos.forEach(function (c) { const dy = Math.abs(c.y - prodY); if (dy > 16) return; const dx = (colX !== null) ? Math.abs(c.x - colX) : 0; const s = dx + dy; if (s < melhor) { melhor = s; qty = c.val; } });
            if (qty === null) qty = 1;
            // ⚖️ Peso (P.Liq. KG) e 💲 Valor Unit. da linha — por POSIÇÃO (coluna X × linha Y), olhando inputs e textos.
            const peso = acharNaColuna(colXP, prodY);
            const valorUnit = acharNaColuna(colXV, prodY);
            try { console.log('[FRIG-LER] linha code=' + rawCode + ' qty=' + qty + ' peso=' + peso + ' valorUnit=' + valorUnit + ' nome="' + nome.slice(0, 50) + '"'); } catch (e) {}
            // 🔬 Se o peso não foi achado, despeja TODOS os números na faixa Y da linha (com X e valor)
            // pra eu calibrar a coluna sem precisar adivinhar o DOM.
            if (!peso) {
                try {
                    const perto = numeros.filter(function (n) { return Math.abs(n.y - prodY) <= 22; })
                        .sort(function (a, b) { return a.x - b.x; })
                        .map(function (n) { return Math.round(n.x) + ":" + n.val; });
                    dlog('🔬 DUMP ' + rawCode + ' (prodY=' + Math.round(prodY) + ' colXP=' + colXP + ' colXV=' + colXV + ') nums[x:val]= ' + perto.join("  "));
                } catch (e) {}
            }
            raw.push({ rawCode: rawCode, nome: nome, qty: qty, peso: peso, valorUnit: valorUnit });
        });
        // Lê o código COMO ESTÁ. (Antes tirava um suposto "prefixo de número de linha", o que
        // quebrava códigos reais — ex: 1443 na linha 1 virava 443. Removido.)
        const itens = [], seen = new Set();
        raw.forEach(function (r) { const code = r.rawCode; if (!code || seen.has(code)) return; seen.add(code); itens.push({ code: code, nome: r.nome, qty: r.qty, peso: r.peso, valorUnit: r.valorUnit }); });
        return itens;
    }
    // 💳 Acha o <select> de "Condição de Pagamento" (achando o rótulo perto e o <select> mais próximo
    // dele em Y) e devolve o texto da opção SELECIONADA (ex.: "21 Dias", "À Vista", "Cartão de Crédito")
    // — não só o value cru do SPAmov, que é só um número interno sem significado por fora ("4").
    // Também devolve TODAS as opções, pra gente montar a tabela de conversão valor→texto no futuro.
    function extrairCondicaoPagamento() {
        try {
            const labels = document.querySelectorAll("b, td, div, span, font");
            let labelY = null;
            for (let i = 0; i < labels.length; i++) {
                if (labels[i].children && labels[i].children.length) continue;
                const t = (labels[i].innerText || labels[i].textContent || "").replace(/\s+/g, " ").trim().toLowerCase();
                if (t.length > 40) continue;
                if (t.indexOf("condi") !== -1 && t.indexOf("pagamento") !== -1) {
                    const r = labels[i].getBoundingClientRect();
                    if (r.width && r.height) { labelY = r.top; break; }
                }
            }
            if (labelY === null) return null;
            const selects = document.querySelectorAll("select");
            let melhor = null, melhorD = 1e9;
            selects.forEach(function (sel) {
                const r = sel.getBoundingClientRect();
                if (!r.width || !r.height) return;
                const d = Math.abs(r.top - labelY);
                if (d < 40 && d < melhorD) { melhorD = d; melhor = sel; }
            });
            if (!melhor) return null;
            const opt = melhor.options[melhor.selectedIndex];
            const texto = opt ? (opt.textContent || opt.value || "").replace(/\s+/g, " ").trim() : "";
            const opcoes = [];
            for (let i = 0; i < melhor.options.length; i++) {
                opcoes.push({ valor: melhor.options[i].value, texto: (melhor.options[i].textContent || "").replace(/\s+/g, " ").trim() });
            }
            return { valor: melhor.value, texto: texto, opcoes: opcoes };
        } catch (e) { return null; }
    }
    // logar=true só quando o vendedor PEDIU a leitura (botão 📋). Antes essa linha saía em toda injeção
    // de todo frame — e como a maioria dos frames do SPAmov realmente não tem a tabela, o log vivia
    // cheio de "tabela=NAO achada" mesmo quando estava tudo certo, escondendo o problema de verdade.
    function montarPedidoLeitura(logar) {
        const c = extrairCliente(); const sp = extrairSpamov(); const itens = extrairItens(sp);
        const cond = extrairCondicaoPagamento();
        if (logar) { try { console.log('[FRIG-LER] >>> cliente=' + c.code + ' (' + c.nome + ') | spamov=' + sp + ' | tabela=' + (acharTabelaItens() ? 'achada' : 'NAO achada') + ' | condicaoPagamento=' + (cond ? cond.texto : '(nao achada)') + ' | itens=' + JSON.stringify(itens.map(function (x) { return { c: x.code, q: x.qty, n: (x.nome || '').slice(0, 30) }; }))); } catch (e) {} }
        return { cliente: c.code, clienteNome: c.nome, spamov: sp, itens: itens, condicaoPagamento: cond ? cond.texto : '', condicaoPagamentoValor: cond ? cond.valor : '' };
    }
    function temPedidoLeitura(p) { return p && (p.cliente || p.spamov || (p.itens && p.itens.length > 0)); }
    // ================= FILA DE PEDIDOS =================
    // O vendedor lança VÁRIOS pedidos seguidos no SPAmov. Antes, cada leitura já pulava pro app —
    // então ele ficava indo e voltando site→app→site a cada pedido. Agora o botão SOMA o pedido numa
    // fila e ele continua no SPAmov; só quando termina tudo é que vai pro app, com a fila inteira.
    // A fila vive no chrome.storage (compartilhado entre as abas da extensão) com queda pro
    // localStorage quando não há extensão (Tampermonkey sem @grant).
    const FILA_KEY = "friganso_fila_pedidos";
    function lerFila(cb) {
        try {
            if (window.chrome && chrome.storage && chrome.storage.local) {
                chrome.storage.local.get([FILA_KEY], function (r) { cb((r && r[FILA_KEY]) || []); });
                return;
            }
        } catch (e) {}
        try { cb(JSON.parse(window.localStorage.getItem(FILA_KEY) || "[]")); } catch (e) { cb([]); }
    }
    function salvarFila(fila, cb) {
        try {
            if (window.chrome && chrome.storage && chrome.storage.local) {
                chrome.storage.local.set({ [FILA_KEY]: fila }, function () { cb && cb(); });
                return;
            }
        } catch (e) {}
        try { window.localStorage.setItem(FILA_KEY, JSON.stringify(fila)); } catch (e) {}
        cb && cb();
    }
    function atualizarRotulosFila(fila) {
        const n = fila.length;
        const bAdd = document.getElementById("friganso-erp-btn");
        if (bAdd) bAdd.textContent = n ? "📋 Somar à fila (" + n + " na fila)" : "📋 Somar pedido à fila";
        const bFim = document.getElementById("friganso-fila-btn");
        if (bFim) {
            bFim.style.display = n ? "" : "none";
            bFim.textContent = "✅ Finalizar e abrir o app (" + n + ")";
        }
    }
    function somarPedidoNaFila() {
        const p = montarPedidoLeitura(true);
        if (!temPedidoLeitura(p) || p.itens.length === 0) { alert("Não consegui ler o pedido nesta tela."); return; }
        lerFila(function (fila) {
            // 🧾 Mesmo SPAmov = mesmo pedido. Se reler a mesma tela (ou corrigir um item e ler de novo),
            // SUBSTITUI o que já estava na fila em vez de duplicar o pedido.
            const sp = String(p.spamov || "").trim();
            // ⚠️ o SPAmov mora em x.pedido.spamov, NÃO em x.spamov — procurar no lugar errado fazia o
            // findIndex nunca casar e a fila duplicava o pedido a cada releitura da mesma tela
            const idx = sp ? fila.findIndex(function (x) { return String((x.pedido && x.pedido.spamov) || "").trim() === sp; }) : -1;
            const registro = { pedido: p, ts: Date.now() };
            let msg;
            if (idx >= 0) { fila[idx] = registro; msg = "Pedido do SPAmov " + sp + " ATUALIZADO na fila."; }
            else { fila.push(registro); msg = "Pedido somado à fila."; }
            salvarFila(fila, function () {
                atualizarRotulosFila(fila);
                const nome = p.clienteNome ? (" — " + p.clienteNome) : "";
                alert("✅ " + msg + nome + "\n\nItens: " + p.itens.length + "\nNa fila agora: " + fila.length +
                      "\n\nPode lançar o próximo pedido. Quando terminar, toque em \"Finalizar e abrir o app\".");
            });
        });
    }
    function finalizarFila() {
        lerFila(function (fila) {
            if (!fila.length) { alert("A fila está vazia. Leia ao menos um pedido antes de finalizar."); return; }
            const pedidos = fila.map(function (x) { return x.pedido; });
            const irPro = function (url) {
                const ehCelular = (navigator.maxTouchPoints || 0) > 0;
                if (ehCelular) { try { (window.top || window).location.href = url; } catch (e) { window.location.href = url; } return; }
                try { const w = (window.top || window).open(url, "friganso_erp_app"); if (w && w.focus) w.focus(); }
                catch (e) { window.open(url, "friganso_erp_app"); }
            };
            // limpa a fila só DEPOIS de entregar, pra não perder pedido se algo falhar no meio
            try {
                if (window.chrome && chrome.storage && chrome.storage.local) {
                    chrome.storage.local.set({ friganso_fila_pendente: { pedidos: pedidos, ts: Date.now() } }, function () {
                        salvarFila([], function () { atualizarRotulosFila([]); irPro(APP_URL + "?fila=pendente"); });
                    });
                    return;
                }
            } catch (e) {}
            const b64 = btoa(unescape(encodeURIComponent(JSON.stringify(pedidos))));
            salvarFila([], function () { atualizarRotulosFila([]); irPro(APP_URL + "?filaJson=" + encodeURIComponent(b64)); });
        });
    }

    function enviarParaApp() {
        const p = montarPedidoLeitura(true);
        if (!temPedidoLeitura(p) || p.itens.length === 0) { alert("Não consegui ler o pedido nesta tela."); return; }
        const b64 = btoa(unescape(encodeURIComponent(JSON.stringify(p))));
        const url = APP_URL + "?pedidojson=" + encodeURIComponent(b64);
        // Celular (toque): abrir aba nova no Firefox costuma ser bloqueado/perdido -> navega a PRÓPRIA aba.
        // Detecta por toque porque no SPAmov a UA está forçada como PC (não dá pra confiar no userAgent/largura).
        const ehCelular = (navigator.maxTouchPoints || 0) > 0;
        if (ehCelular) {
            try { (window.top || window).location.href = url; }
            catch (e) { window.location.href = url; }
            return;
        }
        try { const w = (window.top || window).open(url, "friganso_erp_app"); if (w && w.focus) w.focus(); }
        catch (e) { window.open(url, "friganso_erp_app"); }
    }
    // ================= LISTA DE PREÇOS (catálogo) =================
    // Lê a tela "Lista de Preços" do SPAmov (com.listapreco.spadim) e monta a Tabela do site DIRETO
    // da tela viva — sem precisar exportar/anexar PDF nenhum. A lista inteira fica no DOM mesmo
    // rolada pra fora da tela, então dá pra ler tudo de uma vez sem precisar rolar manualmente.
    function ehTelaListaPrecos() {
        return /listapreco/i.test(location.href) || /lista\s*de\s*pre[çc]os/i.test(document.title || "");
    }
    function extrairListaPrecos() {
        // exige o ponto ("UN.") pra não confundir com a célula de dado "UN" que aparece
        // dentro da coluna "Unidade Preço" (mesmo texto, sem ponto, em várias linhas)
        const colUn = colXHeader(document, function (t) { return /^un\.$/.test(t); });
        const colPeso = colXHeader(document, function (t) { return t.indexOf("peso") !== -1 && t.indexOf("liq") !== -1; });
        const colPecas = colXHeader(document, function (t) { return /^pe[çc]as$/.test(t); });
        const colUnidPreco = colXHeader(document, function (t) { return t.indexOf("unidade") !== -1 && t.indexOf("pre") !== -1; });
        const colEstVenda = colXHeader(document, function (t) { return t.indexOf("est") !== -1 && t.indexOf("venda") !== -1; });
        // 💲 Preços (À Vista, Cartão, 07/14/21/28/30/35/45 dias): em vez de calcular a distância até
        // cada cabeçalho (deu errado repetidas vezes — o valor do Cartão saía no lugar do À Vista mesmo
        // com o cabeçalho certo detectado), agora pega TODOS os números com formato de preço da linha
        // e usa a ORDEM da esquerda pra direita, que é sempre fixa nessa tela do SPAmov.
        const diasCols = [7, 14, 21, 28, 30, 35, 45];

        // coleta TODAS as células-folha com texto e posição (uma vez só)
        // ⚠️ lista de tags igual à do extrairItens() (que já funciona certo em produção) — o preço
        // "à vista" tava saindo trocado pelo do Cartão em TODOS os produtos porque a célula dele
        // provavelmente vem numa tag que faltava aqui (ex.: <a>, célula clicável), então ela sumia
        // da coleta e o "mais perto da coluna X" caía sempre na coluna vizinha (Cartão) por engano.
        const todas = [];
        document.querySelectorAll("td, th, span, font, b, div, a, p, label, i, small, strong, em, nobr, li").forEach(function (el) {
            if (el.children && el.children.length) return;
            const t = (el.innerText || el.textContent || "").replace(/\s+/g, " ").trim();
            if (!t || t.length > 90) return;
            const r = el.getBoundingClientRect();
            if (!r.width || !r.height) return;
            todas.push({ x: r.left, y: Math.round(r.top / 4) * 4, t: t });
        });
        // agrupa por linha (Y, com tolerância)
        const porLinha = {};
        todas.forEach(function (c) { if (!porLinha[c.y]) porLinha[c.y] = []; porLinha[c.y].push(c); });

        // limite direito do nome: termina antes da coluna "UN." (se detectada); 1180 é só um fallback
        // pra layouts antigos/sem essa coluna visível.
        const limiteNome = colUn !== null ? colUn - 60 : 1180;

        const produtos = [];
        Object.keys(porLinha).forEach(function (y) {
            const linha = porLinha[y];
            const candCodigo = linha.filter(function (c) { return /^\d{3,7}$/.test(c.t) && c.x < 100; });
            if (!candCodigo.length) return;
            const celCodigo = candCodigo[0];
            const code = celCodigo.t;
            // 📛 O nome vem logo DEPOIS da célula do código — o limite esquerdo é o X do próprio
            // código, não um número fixo. Antes era `c.x >= 100`, chute que valia pro layout antigo:
            // nesta tela o código fica em x=6 e o nome em x=75, então NENHUM nome passava, e como
            // linha sem nome é descartada, as 767 linhas com preço viravam 0 produto ("Não consegui
            // ler a tabela de preços nesta tela"). Descoberto em 2026-08-03 com o 🔍 Ler Página.
            const candNome = linha.filter(function (c) { return c.x > celCodigo.x && c.x < limiteNome && /[A-Za-zÀ-Ú]{3,}/.test(c.t); });
            candNome.sort(function (a, b) { return b.t.length - a.t.length; });
            if (!candNome.length) return;
            const name = candNome[0].t;
            function perto(colX, tol) {
                if (colX === null) return "";
                let melhor = "", melhorD = 1e9;
                linha.forEach(function (c) { const d = Math.abs(c.x - colX); if (d < (tol || 90) && d < melhorD) { melhorD = d; melhor = c.t; } });
                return melhor;
            }
            const tipo = perto(colUn, 90);
            const pesoItem = perto(colPeso, 160);
            const pcsItem = perto(colPecas, 160);
            const unidade = perto(colUnidPreco, 160);
            const kgUn = perto(colEstVenda, 160);
            // 💲 números com CARA de preço (só dígitos + separador + 2 casas — não bate com "1 Kg",
            // "3 Un" nem "12941.8 Kg/253 Un"), na ordem X: [à vista, cartão, 07d, 14d, 21d, 28d, 30d, 35d, 45d]
            const precos = linha
                .filter(function (c) { return /^\d{1,4}[.,]\d{2}$/.test(c.t.trim()); })
                .sort(function (a, b) { return a.x - b.x; })
                .map(function (c) { return parseNumBR(c.t); });
            const originalPrice = precos.length ? precos[0] : null;
            if (originalPrice === null || originalPrice <= 0) return;
            const precoCartao = precos.length > 1 ? precos[1] : null;
            const precosPrazo = {};
            diasCols.forEach(function (n, i) {
                const v = precos[2 + i];
                if (v !== undefined && v !== null) precosPrazo[n] = v;
            });
            produtos.push({ code: code, name: name, tipo: tipo, pesoItem: pesoItem, pcsItem: pcsItem, unidade: unidade, kgUn: kgUn, originalPrice: originalPrice, precoCartao: precoCartao, precosPrazo: precosPrazo });
        });
        return produtos;
    }
    // O APK 3.2 injeta __frigInjected e intercepta pedidojson ANTES da rede,
    // salvando o conteúdo e fechando SpamovActivity. Seu chrome.storage é apenas
    // um shim de localStorage do SPAmov: NÃO é compartilhado com a WebView do ERP.
    function ehNavegadorAndroid() { return window.__frigInjected === true; }
    function retornarAoAndroid(payload) {
        const b64 = btoa(unescape(encodeURIComponent(JSON.stringify(payload))));
        // Esquema local: nenhum catálogo é enviado a um servidor ou aba da internet.
        const url = 'friganso://retorno?pedidojson=' + encodeURIComponent(b64);
        try { window.top.location.href = url; } catch (e) { window.location.href = url; }
    }
    function enviarTabelaParaApp() {
        const produtos = extrairListaPrecos();
        if (!produtos.length) { if (ehNavegadorAndroid()) statusBox()("Abra a Lista de Preços e carregue os produtos antes de enviar a tabela."); else alert("Não consegui ler a tabela de preços nesta tela."); return; }
        if (ehNavegadorAndroid()) {
            retornarAoAndroid({ frigansoRetorno: 1, tipo: 'tabela', produtos: produtos });
            return;
        }
        // 🚫 NÃO manda a tabela inteira pela URL — com muitos produtos ela fica gigante e o próprio
        // GitHub Pages/CDN não aguenta (dá "I/O error"). Usa o chrome.storage da extensão (compartilhado
        // entre todas as abas dela, sem limite de tamanho de URL) e navega com uma URL curtinha.
        try {
            if (window.chrome && chrome.storage && chrome.storage.local) {
                chrome.storage.local.set({ friganso_tabela_pendente: { produtos: produtos, ts: Date.now() } }, function () {
                    const url = APP_URL + "?tabela=pendente";
                    const ehCelular = (navigator.maxTouchPoints || 0) > 0;
                    if (ehCelular) { try { (window.top || window).location.href = url; } catch (e) { window.location.href = url; } return; }
                    try { const w = (window.top || window).open(url, "friganso_erp_app"); if (w && w.focus) w.focus(); }
                    catch (e) { window.open(url, "friganso_erp_app"); }
                });
                return;
            }
        } catch (e) {}
        // Sem chrome.storage disponível (ex.: Tampermonkey sem @grant): volta pro jeito antigo,
        // que só funciona bem com poucos produtos (URL grande demais pode falhar).
        const b64 = btoa(unescape(encodeURIComponent(JSON.stringify(produtos))));
        const url = APP_URL + "?tabelaJson=" + encodeURIComponent(b64);
        const ehCelular = (navigator.maxTouchPoints || 0) > 0;
        if (ehCelular) {
            try { (window.top || window).location.href = url; } catch (e) { window.location.href = url; }
            return;
        }
        try { const w = (window.top || window).open(url, "friganso_erp_app"); if (w && w.focus) w.focus(); }
        catch (e) { window.open(url, "friganso_erp_app"); }
    }

    // ================= PROCURA DE PESSOAS (cadastro de clientes) =================
    // Lê a tela "Procura de Pessoas" do SPAmov (system.spadim) e traz o cadastro completo dos clientes
    // pro app: nome, CNPJ/CPF, endereço quebrado em partes, telefone, status e limite/saldo de crédito.
    // ⚠️ Diferente da Lista de Preços, aqui cada célula de dado cai EXATAMENTE no mesmo X da coluna do
    // cabeçalho (conferido num diagnóstico real: 788 células, 60 clientes, zero desalinhamento). Então
    // o mapeamento é por X exato com folga de 2px — nada de "achar o mais próximo", que é o que já deu
    // problema duas vezes nas outras telas.
    function coletarCelulasTabela() {
        const cels = [];
        document.querySelectorAll("td, th, b, font, span, div, nobr, a").forEach(function (el) {
            for (var k = 0; k < el.children.length; k++) { if (el.children[k].tagName !== "BR") return; }
            const t = (el.innerText || el.textContent || "").replace(/\s+/g, " ").trim();
            if (!t || t.length > 200) return;
            const r = el.getBoundingClientRect();
            if (!r.width || !r.height) return;
            cels.push({ x: Math.round(r.left), y: Math.round(r.top), t: t });
        });
        return cels;
    }
    // Acha a linha de cabeçalho do resultado ANCORANDO NOS DADOS, não em nomes de coluna.
    // ⚠️ A 1ª versão exigia "Nome / Razão Social" E "CNPF / CNPJ" no cabeçalho — e quebrou na hora em
    // que o usuário montou o relatório com "Fantasia" no lugar do nome e sem o CNPJ. O relatório é
    // TOTALMENTE configurável (o usuário escolhe quais colunas quer), então o único ponto fixo é o
    // formato do ID: "[j] 48016" / "[f] 41984". Então: acha a 1ª linha de dados por esse padrão e
    // pega como cabeçalho a última linha ACIMA dela que tenha um "ID" na mesma coluna.
    function acharCabecalhoClientes(cels) {
        const porY = {};
        cels.forEach(function (c) { (porY[c.y] = porY[c.y] || []).push(c); });
        const ys = Object.keys(porY).map(Number).sort(function (a, b) { return a - b; });

        let yDados = null, xId = null;
        for (var i = 0; i < ys.length; i++) {
            const cand = porY[ys[i]].filter(function (c) { return /^\[[a-z]\]\s*\d{3,}$/i.test(c.t); });
            if (cand.length) { yDados = ys[i]; xId = cand[0].x; break; }
        }
        if (yDados === null) return null;

        let melhor = null;
        for (var k = 0; k < ys.length; k++) {
            if (ys[k] >= yDados) break;
            const temId = porY[ys[k]].some(function (c) { return /^id$/i.test(c.t) && Math.abs(c.x - xId) <= 30; });
            if (temId) melhor = { y: ys[k], cols: porY[ys[k]].slice() };
        }
        return melhor;
    }
    function ehTelaClientes() {
        if (/procura\s+de\s+pessoas/i.test(document.title || "")) return true;
        if (!/system\.spadim/i.test(location.href)) return false;
        const txt = (document.body && document.body.innerText) || "";
        return /raz[ãa]o\s*social/i.test(txt) && /cn?p[fj]\s*\/\s*cnpj/i.test(txt);
    }
    function extrairClientes() {
        const cels = coletarCelulasTabela();
        const cab = acharCabecalhoClientes(cels);
        if (!cab) return { clientes: [], faixa: null };
        const cols = cab.cols.slice().sort(function (a, b) { return a.x - b.x; });
        function colunaDoX(x) {
            for (var i = 0; i < cols.length; i++) { if (Math.abs(cols[i].x - x) <= 2) return cols[i].t; }
            return null;
        }
        // pega o valor da coluna cujo TÍTULO casa com a regex (o usuário pode reordenar as colunas)
        function val(o, re) { for (var k in o) { if (Object.prototype.hasOwnProperty.call(o, k) && re.test(k)) return (o[k] || "").trim(); } return ""; }
        // tenta várias regras em ORDEM DE PREFERÊNCIA e devolve a primeira que tiver valor — o
        // relatório é configurável, então o nome pode vir como "Nome / Razão Social" OU como
        // "Fantasia / Apelido", dependendo do que o usuário marcou
        function valPref(o) {
            for (var i = 1; i < arguments.length; i++) { const v = val(o, arguments[i]); if (v) return v; }
            return "";
        }

        const porY = {};
        cels.forEach(function (c) { if (c.y > cab.y) (porY[c.y] = porY[c.y] || []).push(c); });

        const clientes = [];
        Object.keys(porY).map(Number).sort(function (a, b) { return a - b; }).forEach(function (y) {
            const o = {};
            porY[y].forEach(function (c) { const nome = colunaDoX(c.x); if (nome) o[nome] = c.t; });
            const idBruto = val(o, /^id$/i);
            // rodapé ("De: 1 à 60"), paginação e linhas de controle não têm ID numérico — caem fora aqui
            if (!idBruto || !/\d{3,}/.test(idBruto)) return;
            // "[j] 48016" -> tipo "j" (jurídica) / "f" (física) + código limpo. Mesmo formato que a
            // importação por planilha do site já entende.
            const mTipo = idBruto.match(/\[([a-z])\]/i);
            const code = idBruto.replace(/^\s*\[[a-z]\]\s*/i, "").trim();
            if (!code) return;
            const rua = val(o, /^rua$/i), numero = val(o, /^n[úu]mero$/i), compl = val(o, /complemento/i);
            const logradouro = [rua, numero].filter(Boolean).join(", ") + (compl ? " - " + compl : "");
            clientes.push({
                code: code,
                tipo: mTipo ? mTipo[1].toLowerCase() : "",
                // preferência: razão social > nome > fantasia/apelido (o que o usuário tiver marcado)
                name: valPref(o, /raz[ãa]o\s*social/i, /^nome/i, /fantasia|apelido/i),
                cnpj: val(o, /cn?p[fj]/i),
                status: val(o, /^status$/i),
                uf: val(o, /^uf$/i),
                municipio: val(o, /munic[íi]pio/i),
                bairro: val(o, /^bairro$/i),
                logradouro: logradouro,
                cep: val(o, /c\.?e\.?p/i),
                telefone: val(o, /^telefone$/i),
                limiteCredito: val(o, /limite\s*de\s*cr[ée]dito/i),
                saldoCredito: val(o, /saldo\s*(de\s*)?cr[ée]dito/i),
                bloqueio: val(o, /ocorr[êe]ncia\s*de\s*bloqueio|vendas\s*bloqueada/i)
            });
        });

        // 🔢 O rodapé às vezes traz "Número de Pessoas: 60, De: 1 à 30" — quando traz, o total é CERTO
        // e não precisa ser adivinhado pelo tamanho da página (era o que a 1ª versão fazia).
        let faixa = null, total = 0;
        try {
            const txt = (document.body && document.body.innerText) || "";
            const mF = txt.match(/De:\s*(\d+)\s*[àaá]\s*(\d+)/i);
            if (mF) faixa = { de: Number(mF[1]), ate: Number(mF[2]) };
            const mT = txt.match(/N[úu]mero\s+de\s+Pessoas:\s*(\d+)/i);
            if (mT) total = Number(mT[1]);
        } catch (e) {}
        return { clientes: clientes, faixa: faixa, total: total };
    }
    // 🔢 Campo "Pessoas por Página" e botão "Procurar" da Procura de Pessoas. Ancorados no RÓTULO e no
    // value do botão (não em X fixo — ver a lição do X fixo no CONTEXTO-DO-PROJETO.md).
    function acharCampoPorPagina() {
        let rot = null;
        document.querySelectorAll("td, th, b, font, span, div, nobr, label").forEach(function (el) {
            if (rot) return;
            for (var k = 0; k < el.children.length; k++) { if (el.children[k].tagName !== "BR") return; }
            const t = (el.innerText || el.textContent || "").replace(/\s+/g, " ").trim();
            if (!/pessoas\s+por\s+p[áa]gina/i.test(t)) return;
            const r = el.getBoundingClientRect();
            if (!r.width || !r.height) return;
            rot = { x: r.left, y: r.top };
        });
        if (!rot) return null;
        let melhor = null, melhorD = 1e9;
        document.querySelectorAll("input").forEach(function (el) {
            const tipo = (el.type || "text").toLowerCase();
            if (tipo !== "text") return;
            const r = el.getBoundingClientRect();
            if (!r.width || !r.height) return;
            const d = Math.abs(r.left - rot.x) + Math.abs(r.top - rot.y);
            if (d < melhorD && d < 400) { melhorD = d; melhor = el; }
        });
        return melhor;
    }
    function acharBotaoProcurar() {
        let achado = null;
        document.querySelectorAll("input").forEach(function (el) {
            if (achado) return;
            const tipo = (el.type || "").toLowerCase();
            if (tipo !== "submit" && tipo !== "button") return;
            if (/procurar/i.test(el.value || "")) achado = el;
        });
        return achado;
    }
    function enviarClientesParaApp() {
        const r = extrairClientes();
        const clientes = r.clientes;
        if (!clientes.length) {
            alert(
                "Não consegui ler a lista de clientes nesta tela.\n\n" +
                "Confira se:\n" +
                "• você já clicou em Procurar (a lista precisa estar aparecendo);\n" +
                "• a coluna ID está marcada — é ela que identifica cada cliente (aparece como \"[j] 48016\").\n\n" +
                "Se a lista está na tela e mesmo assim deu isso, use o 🔍 Ler Página e me mande o arquivo."
            );
            return;
        }
        // ⚠️ Ficou gente de fora? Duas formas de descobrir, nessa ordem:
        //  1. o rodapé às vezes traz "Número de Pessoas: 60, De: 1 à 30" — aí o total é CERTO;
        //  2. quando esse texto não aparece (depende de como o relatório foi montado), sobra o
        //     indício de sempre: leu exatamente o tanto de "Pessoas por Página" -> provavelmente há mais.
        const total = r.total || 0;
        const campoPP = acharCampoPorPagina();
        const porPagina = campoPP ? parseInt(String(campoPP.value).replace(/\D/g, ""), 10) : 0;
        const faltaGente = total ? (clientes.length < total) : (porPagina > 0 && clientes.length >= porPagina);
        if (faltaGente) {
            const quanto = total
                ? "Li " + clientes.length + " de " + total + " clientes — o resto está nas próximas páginas."
                : "Li " + clientes.length + " cliente(s), exatamente o limite de \"Pessoas por Página\" — pode ter mais gente nas próximas páginas.";
            const btnProcurar = acharBotaoProcurar();
            if (campoPP && btnProcurar) {
                const aumentar = confirm(
                    quanto + "\n\n" +
                    "OK = trago todos de uma vez (aumento \"Pessoas por Página\" e refaço a busca; depois é só clicar no botão de novo)\n" +
                    "Cancelar = enviar só estes " + clientes.length
                );
                if (aumentar) {
                    try {
                        // folga boa em cima do total, pra não precisar mexer nisso a cada cliente novo
                        campoPP.value = String(Math.max(1000, total * 2));
                        campoPP.dispatchEvent(new Event("change", { bubbles: true }));
                        btnProcurar.click();
                    } catch (e) { alert("Não consegui refazer a busca sozinho. Aumente o campo \"Pessoas por Página\" na mão e clique em Procurar."); }
                    return;
                }
            } else {
                const segue = confirm(
                    quanto + "\n\n" +
                    "Pra trazer todos: aumente o campo \"Pessoas por Página\", clique em Procurar e use este botão de novo.\n\n" +
                    "Quer enviar só estes " + clientes.length + " mesmo?"
                );
                if (!segue) return;
            }
        }
        const payload = { clientes: clientes, ts: Date.now() };
        try {
            if (window.chrome && chrome.storage && chrome.storage.local) {
                chrome.storage.local.set({ friganso_clientes_pendente: payload }, function () {
                    const url = APP_URL + "?clientes=pendente";
                    const ehCelular = (navigator.maxTouchPoints || 0) > 0;
                    if (ehCelular) { try { (window.top || window).location.href = url; } catch (e) { window.location.href = url; } return; }
                    try { const w = (window.top || window).open(url, "friganso_erp_app"); if (w && w.focus) w.focus(); }
                    catch (e) { window.open(url, "friganso_erp_app"); }
                });
                return;
            }
        } catch (e) {}
        // Fallback sem chrome.storage (Tampermonkey sem @grant): manda pela URL mesmo.
        const b64 = btoa(unescape(encodeURIComponent(JSON.stringify(clientes))));
        const url = APP_URL + "?clientesJson=" + encodeURIComponent(b64);
        const ehCelular = (navigator.maxTouchPoints || 0) > 0;
        if (ehCelular) { try { (window.top || window).location.href = url; } catch (e) { window.location.href = url; } return; }
        try { const w = (window.top || window).open(url, "friganso_erp_app"); if (w && w.focus) w.focus(); }
        catch (e) { window.open(url, "friganso_erp_app"); }
    }

    // ================= RELATÓRIO DE VENDAS (faturamento real) =================
    // Lê a tela de relatório de vendas do SPAmov (a que lista pedidos por SPAMOV, com peso EMBARCADO
    // e FATURADO reais — não a estimativa "Valor" do pedido) e manda pro app. Isso substitui/corrige
    // o faturamento que o app hoje só estima a partir do que foi digitado no Resumo.
    function ehTelaRelatorioVendas() {
        const bt = bodyText();
        return /faturado/i.test(bt) && /embarcado/i.test(bt) && /spamov/i.test(bt);
    }
    // 🧭 LEITURA ESTRUTURAL DO RELATÓRIO (por COLUNA, não por pixel)
    // ------------------------------------------------------------------
    // Lição nº1 do CONTEXTO-DO-PROJETO ("extração por ordem, não distância") aplicada aqui: a versão
    // antiga procurava o "E"/"D" de devolução numa faixa fixa de tela (x entre 600 e 900). Essa faixa
    // depende da largura da janela, do zoom e do tamanho do nome do cliente — em 09/09/2026 as células
    // estavam em x=554 e x=576, ou seja, FORA da faixa: nenhuma devolução era detectada e todas
    // entravam somando como venda. Agora a gente acha a coluna pelo CABEÇALHO ("E/S", "DEV", "CFOP")
    // e lê a célula certa do <tr>, que não se mexe com o tamanho da tela.
    function normLabelRel(s) { return (s || "").replace(/\s+/g, " ").trim().toUpperCase().replace(/[. ]/g, ""); }

    // 📅 Data/hora do relatório: "03-09-2026 20:04:37". Fica aqui em cima (e não dentro da
    // extrairRelatorioVendas) porque a lerLinhaPedido também precisa dela.
    const RE_DATA_REL = /^(\d{2})-(\d{2})-(\d{4})\s+\d{2}:\d{2}:\d{2}$/;

    // Mapa tabela -> { es, dev, cfop } com o índice real de cada coluna, lido do cabeçalho.
    function mapaColunasRelatorio(doc) {
        const mapas = new Map();
        const tabelas = doc.querySelectorAll("table");
        for (let t = 0; t < tabelas.length; t++) {
            const rows = tabelas[t].rows;
            for (let r = 0; r < Math.min(rows.length, 5); r++) {
                const cs = rows[r].cells, m = {};
                for (let i = 0; i < cs.length; i++) {
                    const L = normLabelRel(cs[i].textContent);
                    if (L === "E/S") m.es = i;
                    else if (L === "DATA") m.data = i;
                    else if (L === "DEV") m.dev = i;
                    else if (L === "CFOP") m.cfop = i;
                }
                if (m.es != null && m.dev != null) { mapas.set(tabelas[t], m); break; }
            }
        }
        return mapas;
    }

    // Lê a linha do pedido a partir do <a> do número SPAMOV. Devolve null se não der pra ler
    // estruturalmente (aí o chamador cai no plano B).
    function lerLinhaPedido(elA, mapas) {
        try {
            if (!elA || !elA.closest) return null;
            const tr = elA.closest("tr");
            if (!tr || !tr.cells || !tr.cells.length) return null;
            const txtCel = function (i) { return (i != null && tr.cells[i]) ? (tr.cells[i].textContent || "").trim().toUpperCase() : ""; };
            const bgCel = function (i) { return (i != null && tr.cells[i]) ? ((tr.cells[i].getAttribute("bgcolor") || "").toLowerCase()) : ""; };
            const m = mapas.get(tr.closest("table"));
            let devolucao = null, motivo = "";
            if (m) {
                const es = txtCel(m.es), dev = txtCel(m.dev), cfop = txtCel(m.cfop);
                // Devolução = entrada (E/S = "E"), marcada em DEV, ou CFOP de entrada (1.xxx).
                // Venda normal = E/S "S" e CFOP 5.xxx.
                if (dev === "D" || es === "E" || /^1[.,]/.test(cfop)) { devolucao = true; motivo = "coluna " + (dev === "D" ? "DEV=D" : es === "E" ? "E/S=E" : "CFOP=" + cfop); }
                else if (es === "S" || /^5[.,]/.test(cfop)) { devolucao = false; motivo = "coluna E/S=S"; }
                // Reforço: o SPAmov pinta a célula de amarelo (entrada) e vermelho (devolução).
                if (devolucao === null && (bgCel(m.dev) === "ffcccc" || bgCel(m.es) === "ffffcc")) { devolucao = true; motivo = "bgcolor"; }
            }
            if (devolucao === null) {
                // Plano B ainda SEM pixel: varre só as células desta linha atrás de um "E"/"D" solto
                // (numa venda normal essa coluna mostra "S", e nenhuma outra célula da linha é uma
                // letra sozinha) ou de uma célula pintada de vermelho/amarelo.
                for (let i = 0; i < tr.cells.length; i++) {
                    const c = tr.cells[i];
                    if (c.children.length) continue;
                    const t = (c.textContent || "").trim().toUpperCase();
                    const bg = (c.getAttribute("bgcolor") || "").toLowerCase();
                    if (t === "D" || t === "E" || bg === "ffcccc") { devolucao = true; motivo = "linha:" + (t || bg); break; }
                }
                if (devolucao === null) { devolucao = false; motivo = "sem marca"; }
            }
            // 💰 Faturado do pedido = ÚLTIMA célula da linha (a anterior é o "Valor" do pedido, que é
            // só estimativa). Antes isso era pego por pixel (x > 2000) e também estava morto: nesta
            // tela o valor fica em x=1643, então faturadoTotal vinha null em TODO pedido — o que de
            // quebra desligava a conferência "soma dos itens x total do pedido" lá no app.
            // A coluna VALOR tem DUAS sub-colunas: "PEDIDO" (estimativa) e "FATURADO" (o que saiu na
            // nota). A que vale é a FATURADO — a última da linha, e a única em negrito.
            // ⚠️ Se ela vier VAZIA o pedido simplesmente não faturou (ex.: SPAMOV 1963689, uma
            // devolução lançada sem nota): nesse caso o certo é null, NÃO cair na coluna PEDIDO ao
            // lado — isso contaria como faturamento uma estimativa que nunca virou dinheiro.
            let celFat = null;
            for (let i = tr.cells.length - 1; i >= 0; i--) { if (tr.cells[i].querySelector("b")) { celFat = tr.cells[i]; break; } }
            if (!celFat) celFat = tr.cells[tr.cells.length - 1];
            const mFat = ((celFat.textContent || "").trim()).match(/^-?\d{1,3}(?:\.\d{3})*,\d{2}$/);
            const faturadoTotal = mFat ? Math.abs(parseFloat(mFat[0].replace(/\./g, "").replace(",", "."))) : null;
            // 📅 DATA DO PEDIDO — lida DESTA linha, nunca das vizinhas.
            // ⚠️ Quarta vez do mesmo vício de "distância" (04/07, 03/08, 09/09-devolução e agora):
            // a versão antiga juntava as células de TRÊS linhas (a de cima, a atual e a de baixo),
            // filtrava as que pareciam data e pegava a de menor x. Só que a coluna DATA fica no MESMO
            // x em todas as linhas — o desempate por x é um empate. Como o sort do JS é estável, quem
            // sobrava era a primeira da lista: a data da linha DE CIMA, ou seja, a do pedido ANTERIOR.
            // Por isso "todas as datas certinhas na tela" viravam pedidos com o dia trocado ao
            // importar histórico grande. Aqui a linha é uma só, então não tem de quem herdar.
            // Das duas datas da linha (DATA do pedido e PREV de entrega) a que vale é a PRIMEIRA em
            // ordem de coluna — a mesma regra de sempre: ordem, não posição.
            let dia = null;
            const celData = (m && m.data != null && tr.cells[m.data]) ? tr.cells[m.data] : null;
            let mData = celData ? ((celData.textContent || "").trim()).match(RE_DATA_REL) : null;
            if (!mData) {
                for (let i = 0; i < tr.cells.length; i++) {
                    const cand = ((tr.cells[i].textContent || "").trim()).match(RE_DATA_REL);
                    if (cand) { mData = cand; break; }
                }
            }
            if (mData) dia = mData[3] + "-" + mData[2] + "-" + mData[1];
            // estrutural = true diz pro chamador confiar nesse null (é "não faturou") em vez de sair
            // procurando um número parecido na tela.
            return { devolucao: devolucao, motivo: motivo, faturadoTotal: faturadoTotal, dia: dia, estrutural: true };
        } catch (e) { return null; }
    }

    function extrairRelatorioVendas() {
        // Mesma coleta de "célula-folha com posição" usada no diagnóstico — mas direto da tela viva,
        // sem precisar gerar/copiar um arquivo.
        const textos = [];
        document.querySelectorAll("td, th, div, span, font, b, a, label, li, nobr, small, strong").forEach(function (el) {
            // "folha" = sem filhos-elemento, OU só com <br> — a coluna de data/hora do pedido (ex.:
            // "01-07-2026<br>21:57:05") usa <br> entre a data e a hora, e sem essa tolerância a célula
            // inteira era descartada (por isso o import caía tudo pra data de hoje).
            for (var k = 0; k < el.children.length; k++) { if (el.children[k].tagName !== "BR") return; }
            const t = (el.innerText || el.textContent || "").replace(/\s+/g, " ").trim();
            // Nomes de cliente compostos (ex.: "[j] 48094 - Viter Distribuidora de Bebidas
            // Ltda/distribuidora do Junior", 72 caracteres) passavam do limite de 60 e sumiam —
            // por isso ~37% dos pedidos vinham "sem cliente identificado" mesmo tendo o dado na tela.
            if (!t || t.length > 200) return;
            const r = el.getBoundingClientRect();
            if (!r.width || !r.height) return;
            textos.push({ x: Math.round(r.left), y: Math.round(r.top), t: t, tag: el.tagName, el: el });
        });
        // Captura atributo "title"/tooltip também — caso a data só apareça ali em vez do texto visível.
        document.querySelectorAll("[title]").forEach(function (el) {
            const tit = (el.getAttribute("title") || "").replace(/\s+/g, " ").trim();
            if (!tit || tit.length > 200) return;
            const r = el.getBoundingClientRect();
            if (!r.width || !r.height) return;
            textos.push({ x: Math.round(r.left), y: Math.round(r.top), t: tit, tag: el.tagName, el: el });
        });
        if (!textos.length) return [];

        // Agrupa em "linhas visuais" por Y com tolerância (o relatório espalha uma mesma linha lógica
        // em Y ligeiramente diferentes por causa de sub-elementos com fonte/estilo diferente).
        const ordenados = textos.slice().sort(function (a, b) { return a.y - b.y || a.x - b.x; });
        const clusters = [];
        ordenados.forEach(function (t) {
            let cluster = clusters[clusters.length - 1];
            if (!cluster || t.y - cluster.yMax > 10) { cluster = { yMax: t.y, itens: [] }; clusters.push(cluster); }
            cluster.yMax = Math.max(cluster.yMax, t.y);
            cluster.itens.push(t);
        });
        clusters.forEach(function (c) { c.itens.sort(function (a, b) { return a.x - b.x; }); });

        // ⚠️ O "-?" não é decoração: nas linhas de DEVOLUÇÃO o SPAmov manda quantidade e peso
        // negativos (-2, -44,8000). Sem isso a linha inteira era lida com peso 0, o app descartava o
        // item (filtro peso > 0) e a devolução sumia do relatório sem ninguém perceber.
        const reCurrency = /^-?\d{1,3}(\.\d{3})*,\d{2}$/;     // 6.133,60 / -460,72
        const reKg = /^-?\d{1,4},\d{4}$/;                      // 278,8000 / -49,8000
        const reCliente = /\[([jf])\]\s*(\d+)\s*-\s*(.+)/i;    // [j] 86625 - dmb Produtos Ltda
        const reItem = /^(\d+)\s*-\s*(.+)/;                    // 1602 - DIANTEIRO BOVINO
        const reSpamov = /^\d{5,8}$/;
        const reData = /^(\d{2})-(\d{2})-(\d{4})\s+\d{2}:\d{2}:\d{2}$/; // 01-07-2026 21:57:05

        const mapas = mapaColunasRelatorio(document);

        const pedidos = [];
        let atual = null;
        for (let ci = 0; ci < clusters.length; ci++) {
            const cluster = clusters[ci];
            const cells = cluster.itens;

            // Início de um pedido novo: célula tag "A" (link) com texto só-dígitos = número do SPAMOV.
            let cellSpamov = null;
            for (let i = 0; i < cells.length; i++) { if (cells[i].tag === "A" && reSpamov.test(cells[i].t.trim())) { cellSpamov = cells[i]; break; } }
            if (cellSpamov) {
                if (atual) pedidos.push(atual);
                atual = { spamov: cellSpamov.t.trim(), clienteCode: "", clienteNome: "", tipoPessoa: "", faturadoTotal: null, dia: null, devolucao: false, devolvido: false, motivoDevolucao: "", lidoDaTabela: false, itens: [] };
                const vizinhos = [clusters[ci - 1], cluster, clusters[ci + 1]].filter(Boolean).reduce(function (a, c) { return a.concat(c.itens); }, []);
                // 🔴 DEVOLUÇÃO: lida pela COLUNA (E/S, DEV, CFOP), não por posição na tela.
                // A devolução NÃO é mais descartada — ela é uma venda que voltou, então entra no
                // relatório com sinal negativo lá no fim da função. Descartar deixava a venda
                // original contada cheia e inflava o mês.
                const linha = lerLinhaPedido(cellSpamov.el, mapas);
                if (linha) {
                    atual.devolucao = !!linha.devolucao;
                    atual.motivoDevolucao = linha.motivo || "";
                    atual.faturadoTotal = linha.faturadoTotal;
                    atual.dia = linha.dia || null;
                    atual.lidoDaTabela = !!linha.estrutural;
                }
                atual.devolvido = atual.devolucao;
                let cCliente = null;
                for (let i = 0; i < vizinhos.length; i++) { if (reCliente.test(vizinhos[i].t)) { cCliente = vizinhos[i]; break; } }
                if (cCliente) {
                    const m = cCliente.t.match(reCliente);
                    atual.tipoPessoa = m[1].toLowerCase() === "j" ? "juridica" : "fisica";
                    atual.clienteCode = m[2];
                    atual.clienteNome = m[3].trim();
                }
                // 📅 Plano B da data — só entra se a leitura pela linha (lerLinhaPedido) falhou.
                // ⚠️ Olha SÓ o cluster do próprio pedido. NUNCA os vizinhos: era daí que vinha a data
                // do pedido de cima, porque a coluna DATA tem o mesmo x em toda linha e o desempate
                // por x não desempata nada.
                if (!atual.dia) {
                    const candidatosData = cells.filter(function (c) { return reData.test(c.t.trim()); });
                    if (candidatosData.length) {
                        candidatosData.sort(function (a, b) { return a.x - b.x; });
                        const md = candidatosData[0].t.trim().match(reData);
                        atual.dia = md[3] + "-" + md[2] + "-" + md[1];
                    }
                }
                // Faturado do pedido = célula "B" em moeda, a mais à direita do cabeçalho (a "Valor" do
                // pedido, mais cedo na linha, é só estimativa — não usar essa).
                // Só cai aqui se a leitura estrutural acima não achou o valor (tela fora do padrão).
                // Sem o antigo "c.x > 2000": é a moeda em negrito mais à DIREITA do cabeçalho, seja
                // qual for a largura da tela.
                if (atual.faturadoTotal == null && !atual.lidoDaTabela) {
                    const candidatosFat = vizinhos.filter(function (c) { return c.tag === "B" && reCurrency.test(c.t.trim()); });
                    if (candidatosFat.length) {
                        candidatosFat.sort(function (a, b) { return b.x - a.x; });
                        atual.faturadoTotal = Math.abs(parseFloat(candidatosFat[0].t.trim().replace(/\./g, "").replace(",", ".")));
                    }
                }
                continue;
            }

            if (!atual) continue;

            const cellItem = cells.filter(function (c) { return c.x < 400 && c.tag === "TD" && reItem.test(c.t.trim()); })[0];
            if (!cellItem) continue; // cabeçalho de tabela, linha TOTAL etc. — ignora
            const mItem = cellItem.t.trim().match(reItem);
            const code = mItem[1];
            const name = mItem[2].trim();

            const cellKg = cells.filter(function (c) { return reKg.test(c.t.trim()); })[0];
            let peso = 0, faturado = 0, qty = 1;
            if (cellKg) {
                // Guarda sempre o MÓDULO: quem manda no sinal é o flag devolucao do pedido, aplicado
                // uma vez só no fim. Misturar os dois dava número trocado (o SPAmov manda o peso
                // negativo mas o faturado positivo na mesma linha de devolução).
                peso = Math.abs(parseFloat(cellKg.t.trim().replace(",", ".")));
                const candidatosF = cells.filter(function (c) { return c.x > cellKg.x && reCurrency.test(c.t.trim()); });
                if (candidatosF.length) {
                    candidatosF.sort(function (a, b) { return a.x - b.x; });
                    faturado = Math.abs(parseFloat(candidatosF[0].t.trim().replace(/\./g, "").replace(",", ".")));
                }
                const candidatosQty = cells.filter(function (c) { return c.x < cellKg.x && /^-?\d+$/.test(c.t.trim()); });
                if (candidatosQty.length) {
                    candidatosQty.sort(function (a, b) { return b.x - a.x; });
                    qty = Math.abs(parseInt(candidatosQty[0].t.trim(), 10)) || 1;
                }
            }
            const valorKg = peso > 0 ? Math.round((faturado / peso) * 10000) / 10000 : 0;
            atual.itens.push({ code: code, name: name, qty: qty, peso: peso, faturado: faturado, valorKg: valorKg });
        }
        if (atual) pedidos.push(atual);
        // ➖ Devolução entra NEGATIVA em vez de ser jogada fora. Os itens continuam com peso positivo
        // (o app filtra item com peso <= 0, e a devolução precisa sobreviver a esse filtro); o sinal
        // fica no flag "devolucao" + no faturadoTotal, e o app aplica na hora de gravar a compra.
        return pedidos.map(function (p) {
            if (p.devolucao && p.faturadoTotal != null) p.faturadoTotal = -Math.abs(p.faturadoTotal);
            return p;
        });
    }
    function enviarRelatorioVendasParaApp() {
        const pedidos = extrairRelatorioVendas();
        if (!pedidos.length) { alert("Não consegui ler nenhum pedido nessa tela."); return; }
        try {
            if (window.chrome && chrome.storage && chrome.storage.local) {
                chrome.storage.local.set({ friganso_relatorio_vendas_pendente: { pedidos: pedidos, ts: Date.now() } }, function () {
                    const url = APP_URL + "?relatorioVendas=pendente";
                    const ehCelular = (navigator.maxTouchPoints || 0) > 0;
                    if (ehCelular) { try { (window.top || window).location.href = url; } catch (e) { window.location.href = url; } return; }
                    try { const w = (window.top || window).open(url, "friganso_erp_app"); if (w && w.focus) w.focus(); }
                    catch (e) { window.open(url, "friganso_erp_app"); }
                });
                return;
            }
        } catch (e) {}
        const b64 = btoa(unescape(encodeURIComponent(JSON.stringify(pedidos))));
        const url = APP_URL + "?relatorioVendasJson=" + encodeURIComponent(b64);
        const ehCelular = (navigator.maxTouchPoints || 0) > 0;
        if (ehCelular) { try { (window.top || window).location.href = url; } catch (e) { window.location.href = url; } return; }
        try { const w = (window.top || window).open(url, "friganso_erp_app"); if (w && w.focus) w.focus(); }
        catch (e) { window.open(url, "friganso_erp_app"); }
    }

    // 📲 Botão NATIVO do app (barra de cima): tenta enviar o resumo deste frame; devolve true se conseguiu.
    try {
        window.__frigEnviarSePuder = function () {
            try {
                const p = montarPedidoLeitura();
                if (temPedidoLeitura(p) && p.itens.length > 0) { enviarParaApp(); return true; }
            } catch (e) {}
            return false;
        };
    } catch (e) {}
    // 📲 Dados CRUS deste frame (sem exigir que ESTE frame tenha cliente+SPAmov+itens todos juntos —
    // no SPAmov o cabeçalho [cliente/SPAmov] e a tabela de itens costumam ficar em frames DIFERENTES
    // do frameset). O app agrega os dados de todos os frames antes de decidir se dá pra montar o pedido.
    try {
        window.__frigDadosFrame = function () {
            try {
                const c = extrairCliente(), sp = extrairSpamov(), itens = extrairItens(sp);
                const cond = extrairCondicaoPagamento();
                const bt = bodyText();
                // 🔬 diagnóstico: pra descobrir se ESTE frame chega a ver a tabela de itens ou não
                return {
                    cliente: c.code, clienteNome: c.nome, spamov: sp, itens: itens,
                    condicaoPagamento: cond ? cond.texto : '', condicaoPagamentoValor: cond ? cond.valor : '',
                    _diag: { url: (location.href || '').slice(0, 90), bodyLen: bt.length, temQuantMov: /quant.{0,4}mov/i.test(bt), temPLiq: /p\.?\s*liq/i.test(bt) }
                };
            } catch (e) { return null; }
        };
    } catch (e) {}

    // 🔍 Diagnóstico GERAL deste frame — todo texto curto + posição (X/Y), campos e o que as funções
    // de leitura acham aqui. Usado pelo botão "🔍 Ler Página": junta isso de TODOS os frames, pra você
    // copiar e colar no chat com o Claude quando algo não estiver lendo certo, ou quando quiser pedir
    // uma automação nova baseada no que a página realmente tem.
    window.__frigDiagnostico = function () {
        try {
            if (!document.body || document.body.tagName === "FRAMESET") return { url: (location.href || "").slice(0, 150), frameset: true };
            // ⚠️ SEM limite de quantidade — o diagnóstico agora alimenta a leitura real da Tabela
            // (que precisa da página inteira, ex.: catálogo com centenas de produtos).
            const textos = [];
            document.querySelectorAll("td, th, div, span, font, b, a, label, li, nobr, small, strong").forEach(function (el) {
                // "folha" = sem filhos-elemento, OU só com <br> — antes um <br> descartava a célula, e a
                // coluna DATA (que mostra "13-07-2026<br>21:44:47") sumia inteira do diagnóstico.
                for (var k = 0; k < el.children.length; k++) { if (el.children[k].tagName !== "BR") return; }
                const t = (el.innerText || el.textContent || "").replace(/\s+/g, " ").trim();
                // Nomes de cliente compostos podem passar de 60 caracteres facilmente — usa o mesmo
                // limite generoso do extrairRelatorioVendas (ver comentário lá) pra não descartá-los.
                if (!t || t.length > 200) return;
                const r = el.getBoundingClientRect();
                if (!r.width || !r.height) return;
                textos.push({ x: Math.round(r.left), y: Math.round(r.top), t: t, tag: el.tagName });
            });
            // 🏷️ Também captura atributos "title"/tooltip — algumas colunas (como a DATA) mostram o
            // valor só no title (aparece ao passar o mouse), então o texto visível vinha vazio.
            document.querySelectorAll("[title]").forEach(function (el) {
                const tit = (el.getAttribute("title") || "").replace(/\s+/g, " ").trim();
                if (!tit || tit.length > 200) return;
                const r = el.getBoundingClientRect();
                if (!r.width || !r.height) return;
                textos.push({ x: Math.round(r.left), y: Math.round(r.top), t: tit, tag: el.tagName, attr: "title" });
            });
            const campos = [];
            document.querySelectorAll("input, select").forEach(function (el) {
                const r = el.getBoundingClientRect();
                if (!r.width || !r.height) return;
                campos.push({ tag: el.tagName, tipo: (el.type || "").toLowerCase(), valor: (el.value || "").slice(0, 40), x: Math.round(r.left), y: Math.round(r.top) });
            });
            let cliente = null, spamov = null, itens = null;
            try { cliente = extrairCliente(); } catch (e) {}
            try { spamov = extrairSpamov(); } catch (e) {}
            try { itens = extrairItens(spamov || ""); } catch (e) {}
            return {
                url: (location.href || "").slice(0, 150), titulo: document.title,
                cliente: cliente, spamov: spamov, itensAchados: itens,
                textos: textos, campos: campos
            };
        } catch (e) { return { erro: String(e && e.message ? e.message : e) }; }
    };

    // Junta o diagnóstico de TODOS os frames, mostra numa caixa pra copiar (e tenta copiar sozinho).
    function gerarDiagnostico() {
        function coletar(w, prof, out) {
            try { if (w.__frigDiagnostico) { const d = w.__frigDiagnostico(); if (d) out.push(Object.assign({ profundidade: prof }, d)); } } catch (e) {}
            try { for (let i = 0; i < w.frames.length; i++) coletar(w.frames[i], prof + 1, out); } catch (e) {}
        }
        const partes = [];
        coletar(window, 0, partes);
        const relatorio = { geradoEm: new Date().toLocaleString("pt-BR"), paginaTop: location.href, totalFrames: partes.length, frames: partes };
        const texto = JSON.stringify(relatorio, null, 1);
        let copiado = false;
        try { if (navigator.clipboard && navigator.clipboard.writeText) { navigator.clipboard.writeText(texto); copiado = true; } } catch (e) {}
        mostrarDiagnosticoModal(texto, copiado);
    }
    function mostrarDiagnosticoModal(texto, copiado) {
        const old = document.getElementById("friganso-diag-modal"); if (old) old.remove();
        const ov = document.createElement("div");
        ov.id = "friganso-diag-modal";
        Object.assign(ov.style, { position: "fixed", inset: "0", background: "rgba(15,23,42,.7)", zIndex: "2147483647", display: "flex", alignItems: "center", justifyContent: "center", fontFamily: "system-ui,sans-serif", padding: "16px" });
        ov.addEventListener("click", function (e) { if (e.target === ov) ov.remove(); });
        const box = document.createElement("div");
        Object.assign(box.style, { background: "#fff", borderRadius: "14px", padding: "16px", width: "640px", maxWidth: "95vw", maxHeight: "85vh", display: "flex", flexDirection: "column", boxShadow: "0 10px 40px rgba(0,0,0,.4)" });
        const titulo = document.createElement("div");
        titulo.textContent = (copiado ? "✅ Copiado! " : "📋 ") + "Cole isso no chat com o Claude";
        Object.assign(titulo.style, { fontWeight: "800", fontSize: "15px", color: "#0f172a", marginBottom: "8px" });
        box.appendChild(titulo);
        const ta = document.createElement("textarea");
        ta.value = texto; ta.readOnly = true;
        Object.assign(ta.style, { flex: "1", minHeight: "300px", fontFamily: "monospace", fontSize: "11px", padding: "8px", border: "1px solid #e2e8f0", borderRadius: "8px", resize: "none", boxSizing: "border-box" });
        box.appendChild(ta);
        const btns = document.createElement("div");
        Object.assign(btns.style, { display: "flex", gap: "8px", marginTop: "10px" });
        const btnCopiar = document.createElement("button");
        btnCopiar.textContent = "📋 Copiar de novo";
        Object.assign(btnCopiar.style, { flex: "1", background: "#e11d48", color: "#fff", border: "none", borderRadius: "8px", padding: "10px", fontWeight: "700", cursor: "pointer" });
        btnCopiar.addEventListener("click", function () {
            ta.focus(); ta.select();
            try { document.execCommand("copy"); } catch (e) {}
            try { navigator.clipboard && navigator.clipboard.writeText(texto); } catch (e) {}
        });
        btns.appendChild(btnCopiar);
        const btnBaixar = document.createElement("button");
        btnBaixar.textContent = "💾 Baixar .txt";
        Object.assign(btnBaixar.style, { flex: "1", background: "#0f172a", color: "#fff", border: "none", borderRadius: "8px", padding: "10px", fontWeight: "700", cursor: "pointer" });
        btnBaixar.addEventListener("click", function () {
            try {
                const blob = new Blob([texto], { type: "text/plain;charset=utf-8" });
                const a = document.createElement("a");
                const agora = new Date();
                const nome = "friganso-diagnostico-" + agora.toISOString().slice(0, 16).replace(/[-:T]/g, "") + ".txt";
                a.href = URL.createObjectURL(blob);
                a.download = nome;
                document.body.appendChild(a);
                a.click();
                document.body.removeChild(a);
                setTimeout(function () { URL.revokeObjectURL(a.href); }, 4000);
            } catch (e) {}
        });
        btns.appendChild(btnBaixar);
        const fechar = document.createElement("button");
        fechar.textContent = "Fechar";
        Object.assign(fechar.style, { background: "#e2e8f0", color: "#334155", border: "none", borderRadius: "8px", padding: "10px 16px", fontWeight: "700", cursor: "pointer" });
        fechar.addEventListener("click", function () { ov.remove(); });
        btns.appendChild(fechar);
        box.appendChild(btns);
        ov.appendChild(box);
        document.body.appendChild(ov);
        ta.focus(); ta.select();
    }

    // ---------- LANÇAMENTO (Fazer Pedido) ----------
    function statusBox() {
        let box = document.getElementById("friganso-status");
        if (!box) {
            box = document.createElement("div"); box.id = "friganso-status";
            Object.assign(box.style, { position: "fixed", top: "10px", left: "50%", transform: "translateX(-50%)", zIndex: "2147483647", background: "#0f172a", color: "#fff", padding: "10px 18px", borderRadius: "10px", fontFamily: "system-ui,sans-serif", fontSize: "13px", fontWeight: "bold", boxShadow: "0 6px 20px rgba(0,0,0,.35)", maxWidth: "92vw", textAlign: "center" });
            document.body.appendChild(box);
        }
        return function (msg) { box.textContent = "🦢 " + msg; };
    }

    // ---- Painel de LOG: fica ESCONDIDO atrás de um ícone pequeno (clica pra abrir) ----
    function ensureLogUI() {
        let btn = document.getElementById("friganso-log-btn");
        if (!btn) {
            btn = document.createElement("button");
            btn.id = "friganso-log-btn"; btn.type = "button"; btn.textContent = "🐞"; btn.title = "Log da extensão (clique para abrir/fechar)";
            Object.assign(btn.style, { position: "fixed", left: "10px", bottom: "10px", width: "34px", height: "34px", borderRadius: "50%", border: "1px solid #334155", background: "#0f172a", color: "#fff", fontSize: "15px", cursor: "pointer", zIndex: "2147483647", boxShadow: "0 4px 12px rgba(0,0,0,.35)", padding: "0", lineHeight: "34px", textAlign: "center" });
            btn.addEventListener("click", function () { const p = document.getElementById("friganso-log"); if (p) p.style.display = (p.style.display === "none" ? "block" : "none"); });
            document.body.appendChild(btn);
        }
        let p = document.getElementById("friganso-log");
        if (!p) {
            p = document.createElement("div"); p.id = "friganso-log";
            Object.assign(p.style, { position: "fixed", left: "10px", bottom: "52px", width: "380px", maxWidth: "48vw", maxHeight: "240px", overflowY: "auto", background: "rgba(2,6,23,0.95)", color: "#cbd5e1", fontFamily: "monospace", fontSize: "11px", lineHeight: "1.5", padding: "8px 10px", borderRadius: "10px", zIndex: "2147483647", border: "1px solid #334155", whiteSpace: "pre-wrap", display: "none" });
            document.body.appendChild(p);
        }
        return p;
    }
    function renderLog(linhas) {
        const p = ensureLogUI(); // garante o ícone; o painel começa escondido
        p.textContent = (linhas || []).join("\n");
        p.scrollTop = p.scrollHeight;
    }
    function dlog(msg) {
        const linha = new Date().toLocaleTimeString() + "  " + msg;
        try { console.log("[FRIG] " + linha); } catch (e) {} // surge no log nativo do app
        try {
            chrome.storage.local.get(["friganso_log"], function (r) {
                const arr = (r && r.friganso_log) || [];
                arr.push(linha); while (arr.length > 80) arr.shift();
                chrome.storage.local.set({ friganso_log: arr });
                renderLog(arr);
            });
        } catch (e) { renderLog([linha]); }
    }
    function limparLog() { try { chrome.storage.local.set({ friganso_log: [] }); } catch (e) {} renderLog([]); }
    function mostrarLogSalvo() { try { chrome.storage.local.get(["friganso_log"], function (r) { const a = (r && r.friganso_log) || []; if (a.length) renderLog(a); }); } catch (e) {} }

    function setInput(el, v) {
        try { el.focus(); } catch (e) {}
        var setter = (function () { try { return Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, "value").set; } catch (e) { return null; } })();
        try { if (setter) setter.call(el, String(v)); else el.value = String(v); } catch (e) { try { el.value = String(v); } catch (e2) {} }
        ["input", "change", "keyup", "blur"].forEach(function (t) { try { el.dispatchEvent(new Event(t, { bubbles: true })); } catch (e) {} });
    }
    // Digitação ROBUSTA: usa o setter nativo (burla controles que revertem o valor) +
    // tenta document.execCommand("insertText") (digitação real, como um teclado).
    function typeInto(el, texto) {
        const s = String(texto);
        try { el.focus(); el.click(); } catch (e) {}
        const setter = (function () { try { return Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, "value").set; } catch (e) { return null; } })();
        const setVal = function (v) { try { if (setter) setter.call(el, v); else el.value = v; } catch (e) { try { el.value = v; } catch (e2) {} } };
        setVal("");
        el.dispatchEvent(new Event("input", { bubbles: true }));
        let ok = false;
        try { ok = document.execCommand && document.execCommand("insertText", false, s); } catch (e) {}
        if (!ok || (el.value || "") !== s) {
            setVal("");
            for (let i = 0; i < s.length; i++) {
                const ch = s[i];
                el.dispatchEvent(new KeyboardEvent("keydown", { bubbles: true, key: ch }));
                el.dispatchEvent(new KeyboardEvent("keypress", { bubbles: true, key: ch }));
                setVal(s.slice(0, i + 1));
                try { el.dispatchEvent(new InputEvent("input", { bubbles: true, data: ch, inputType: "insertText" })); } catch (e) { el.dispatchEvent(new Event("input", { bubbles: true })); }
                el.dispatchEvent(new KeyboardEvent("keyup", { bubbles: true, key: ch }));
            }
        }
        el.dispatchEvent(new Event("change", { bubbles: true }));
    }
    function enter(el) { ["keydown", "keypress", "keyup"].forEach(t => el.dispatchEvent(new KeyboardEvent(t, { bubbles: true, key: "Enter", code: "Enter", keyCode: 13, which: 13 }))); }
    // Força o "saiu do campo" (blur) — no Android o blur sintético não basta, então também tira o foco
    // de verdade e foca outro campo. É isso que faz o SPAmov buscar e mostrar o NOME do cliente.
    function blurDe(el) {
        try {
            ["change", "blur", "focusout"].forEach(function (t) { try { el.dispatchEvent(new Event(t, { bubbles: true })); } catch (e) {} });
            try { if (el.blur) el.blur(); } catch (e) {}
            try {
                var outros = inputsVisiveis().filter(function (i) { return i !== el; });
                if (outros[0] && outros[0].focus) { outros[0].focus(); outros[0].blur && outros[0].blur(); }
                else if (document.body && document.body.focus) { document.body.setAttribute && document.body.setAttribute("tabindex", "-1"); document.body.focus(); }
            } catch (e) {}
        } catch (e) {}
    }
    // Clique robusto: sobe até o elemento realmente clicável e dispara eventos de mouse + click nativo
    function clicar(el) {
        if (!el) return false;
        let alvo = el, p = el;
        for (let i = 0; i < 5 && p; i++) {
            const tem = p.onclick || (p.getAttribute && p.getAttribute("onclick")) || p.tagName === "A" || p.tagName === "BUTTON" || (p.getAttribute && p.getAttribute("href"));
            if (tem) { alvo = p; break; }
            p = p.parentElement;
        }
        try { if (alvo.focus) alvo.focus(); } catch (e) {}
        ["mousedown", "mouseup", "click"].forEach(function (t) { try { alvo.dispatchEvent(new MouseEvent(t, { bubbles: true, cancelable: true, view: window })); } catch (e) {} });
        try { if (alvo.click) alvo.click(); } catch (e) {}
        return true;
    }
    async function esperar(cond, ms) { const t = Date.now(); while (Date.now() - t < ms) { if (cond()) return true; await sleep(200); } return false; }

    // Retângulo EXATO da linha de entrada (a do seletor PRODUTOS / "novo orçamento")
    function linhaEntradaRect() {
        const selects = document.querySelectorAll("select");
        for (let i = 0; i < selects.length; i++) {
            const s = selects[i];
            const txt = Array.from(s.options || []).map(o => o.text).join(" ");
            if (/PRODUTOS/i.test(txt)) { const tr = s.closest("tr"); const r = (tr || s).getBoundingClientRect(); if (r.height) return r; }
        }
        const tds = document.querySelectorAll("td");
        for (let i = 0; i < tds.length; i++) { if (/novo or[çc]amento/i.test(tds[i].innerText || "")) { const tr = tds[i].closest("tr"); const r = (tr || tds[i]).getBoundingClientRect(); if (r.height) return r; } }
        return null;
    }
    function inputsVisiveis() {
        return Array.prototype.slice.call(document.querySelectorAll("input")).filter(function (i) {
            const t = (i.type || "").toLowerCase();
            if (["checkbox", "radio", "hidden", "button", "submit", "image"].indexOf(t) !== -1) return false;
            const r = i.getBoundingClientRect(); return r.width > 10 && r.height > 5;
        });
    }
    // Acha código e quantidade na LINHA DE ENTRADA = a primeira linha de inputs abaixo do
    // cabeçalho "Quant. Mov." (os itens já lançados ficam ABAIXO dela, então são ignorados).
    function camposEntrada() {
        const colX = colXQuant();
        // pega o fim (bottom) do cabeçalho da coluna "Quant. Mov."
        let headerBottom = null;
        document.querySelectorAll("td, th").forEach(function (c) {
            const t = (c.innerText || "").toLowerCase();
            if (t.indexOf("quant") !== -1 && t.indexOf("mov") !== -1) { const r = c.getBoundingClientRect(); if (r.width && (headerBottom == null || r.bottom < headerBottom)) headerBottom = r.bottom; }
        });
        let cand = inputsVisiveis();
        if (headerBottom != null) cand = cand.filter(function (i) { return i.getBoundingClientRect().top >= headerBottom - 4; });
        if (!cand.length) return null;
        // linha de entrada = inputs mais ao TOPO (itens lançados ficam abaixo)
        let minC = Infinity;
        cand.forEach(function (i) { const b = i.getBoundingClientRect(); const cy = b.top + b.height / 2; if (cy < minC) minC = cy; });
        const naLinha = cand.filter(function (i) { const b = i.getBoundingClientRect(); return Math.abs((b.top + b.height / 2) - minC) < 16; });
        if (!naLinha.length) return null;
        let top = Infinity, bottom = -Infinity;
        naLinha.forEach(function (i) { const b = i.getBoundingClientRect(); top = Math.min(top, b.top); bottom = Math.max(bottom, b.bottom); });
        const porX = naLinha.slice().sort(function (a, b) { return a.getBoundingClientRect().left - b.getBoundingClientRect().left; });
        const code = porX[0] || null; // mais à esquerda = código
        let qty = null, bd = 1e9;
        naLinha.forEach(function (i) {
            if (i === code) return;
            const b = i.getBoundingClientRect(); const x = b.left + b.width / 2;
            const d = (colX != null) ? Math.abs(x - colX) : x;
            if (d < bd) { bd = d; qty = i; } // mais próximo da coluna "Quant. Mov." = quantidade
        });
        return { rect: { top: top, bottom: bottom }, n: naLinha.length, code: code, qty: qty };
    }

    // Detecta se um elemento é "verde" (pela cor ou pelo nome do ícone)
    function ehVerde(el) {
        try {
            const cs = getComputedStyle(el);
            const cores = [cs.backgroundColor, cs.color, cs.borderTopColor];
            for (let i = 0; i < cores.length; i++) {
                const m = cores[i] && cores[i].match(/rgba?\((\d+),\s*(\d+),\s*(\d+)/);
                if (m) { const R = +m[1], G = +m[2], B = +m[3]; if (G > 90 && G > R + 20 && G > B + 20) return true; }
            }
            const s = ((el.src || "") + " " + (el.alt || "") + " " + (el.title || "")).toLowerCase();
            if (/verde|green|\bok\b|check|confirm|aceit|salv|grava|adicion/.test(s)) return true;
        } catch (e) {}
        return false;
    }
    // Acha o ✓ verde da linha de entrada (clica pra lançar o item)
    function acharCheckVerde(faixa) {
        if (!faixa) return null;
        const cands = [];
        const els = document.querySelectorAll("img, a, input[type=image], button, span, div, td");
        els.forEach(function (el) {
            const r = el.getBoundingClientRect();
            if (!r.width || !r.height) return;
            const cy = r.top + r.height / 2;
            if (cy < faixa.top - 3 || cy > faixa.bottom + 3) return; // só na linha de entrada
            const txt = ((el.innerText || el.value || "") + "").trim();
            if (/todos/i.test(txt)) return;            // ignora botão "Todos"
            if (txt.length > 6) return;                // ignora textos longos (não é ícone)
            const clicavel = el.tagName === "IMG" || el.tagName === "A" || el.tagName === "INPUT" || el.onclick || el.getAttribute("onclick") || getComputedStyle(el).cursor === "pointer";
            if (!clicavel) return;
            cands.push({ el: el, x: r.left + r.width / 2, verde: ehVerde(el) });
        });
        if (!cands.length) return null;
        const verdes = cands.filter(c => c.verde);
        const lista = verdes.length ? verdes : cands;
        lista.sort((a, b) => b.x - a.x); // mais à direita primeiro (o ✓ fica no fim da linha)
        return lista[0].el;
    }

    // ---------- Estado persistente (sobrevive ao reload "pisca" do site) ----------
    function getRun() { return new Promise(function (res) { try { chrome.storage.local.get(["friganso_run"], function (r) { res((r && r.friganso_run) || null); }); } catch (e) { res(null); } }); }
    function setRun(run) { return new Promise(function (res) { try { chrome.storage.local.set({ friganso_run: run }, function () { res(); }); } catch (e) { res(); } }); }
    function clearRun() { return new Promise(function (res) { try { chrome.storage.local.remove("friganso_run", function () { res(); }); } catch (e) { res(); } }); }
    function ehFrameItens() { return colXQuant() != null; } // frame que tem o cabeçalho "Quant. Mov."

    function acharBotaoNovo() {
        let best = null;
        const els = document.querySelectorAll("a, td, button, span, img, div, input[type=button], input[type=image]");
        for (let i = 0; i < els.length; i++) {
            const e = els[i];
            const t = ((e.value || e.alt || e.title || e.innerText || "") + "").trim();
            if (/^novo$/i.test(t)) { const r = e.getBoundingClientRect(); if (r.width && r.height) { const tam = (e.innerText || "").length; if (!best || tam < best._tam) { best = e; best._tam = tam; } } }
        }
        return best;
    }
    function acharBotaoEnviar() {
        const els = document.querySelectorAll("input[type=button], input[type=submit], input[type=image], button, a, td, span, img");
        for (let i = 0; i < els.length; i++) { const e = els[i]; const t = ((e.value || e.innerText || e.alt || e.title || "") + "").trim(); if (/^enviar$/i.test(t)) { const r = e.getBoundingClientRect(); if (r.width && r.height) return e; } }
        return null;
    }
    function acharCampoCliente() {
        // 1) MELHOR PISTA: o seletor "1. Jurídica / 2. Física" — o campo do ID fica logo à direita dele
        const selects = document.querySelectorAll("select");
        for (let i = 0; i < selects.length; i++) {
            const s = selects[i];
            const txt = Array.from(s.options || []).map(o => o.text).join(" ");
            if (/jur[ií]dica|f[ií]sica/i.test(txt)) {
                const sr = s.getBoundingClientRect();
                if (!sr.width) continue;
                const cy = sr.top + sr.height / 2;
                const inps = inputsVisiveis().filter(function (inp) {
                    const r = inp.getBoundingClientRect();
                    return Math.abs((r.top + r.height / 2) - cy) < 16 && r.left >= sr.right - 4;
                });
                inps.sort(function (a, b) { return a.getBoundingClientRect().left - b.getBoundingClientRect().left; });
                if (inps[0]) return inps[0];
            }
        }
        // 2) Fallback: pelo rótulo "CLIENTE"
        let labelRect = null;
        const cells = document.querySelectorAll("td, th, label, span, div, b");
        for (let i = 0; i < cells.length; i++) {
            const t = (cells[i].innerText || "").trim();
            if (/^cliente\b/i.test(t) && t.length < 12) { const r = cells[i].getBoundingClientRect(); if (r.width && r.height) { labelRect = r; break; } }
        }
        if (!labelRect) return null;
        const cy = labelRect.top + labelRect.height / 2;
        const inps = inputsVisiveis().filter(function (i) {
            const r = i.getBoundingClientRect();
            return Math.abs((r.top + r.height / 2) - cy) < 16 && r.left > labelRect.left;
        });
        inps.sort(function (a, b) { return a.getBoundingClientRect().left - b.getBoundingClientRect().left; });
        return inps[0] || null;
    }
    function ehFramePrincipal() { return ehFrameItens() || /CLIENTE/i.test(bodyText()) || !!acharBotaoNovo(); }

    // Seleciona "1. Jurídica" (CNPJ) ou "2. Física" (CPF) no dropdown do cliente
    function selecionarTipoPessoa(tipo) {
        const selects = document.querySelectorAll("select");
        for (let i = 0; i < selects.length; i++) {
            const s = selects[i];
            const opts = Array.prototype.slice.call(s.options || []);
            const txt = opts.map(o => o.text).join(" ");
            if (/jur[ií]dica/i.test(txt) && /f[ií]sica/i.test(txt)) {
                const re = (tipo === "fisica") ? /f[ií]sica/i : /jur[ií]dica/i;
                for (let j = 0; j < opts.length; j++) {
                    if (re.test(opts[j].text)) {
                        s.value = opts[j].value; s.selectedIndex = j;
                        s.dispatchEvent(new Event("input", { bubbles: true }));
                        s.dispatchEvent(new Event("change", { bubbles: true }));
                        return opts[j].text.trim();
                    }
                }
            }
        }
        return null;
    }

    // Processa UM item por carregamento da página. O clique no verde recarrega o site
    // e, no próximo load, esta função retoma sozinha do próximo item.
    // Detecta se o pedido já está no estado PA (confirmado)
    function estaEmPA() {
        const t = bodyText();
        if (/\bPA\b\s*Mov/i.test(t)) return true;
        // no estado PA aparece a linha expandida: PCP OE PDE OP PDP CP NF DP FIN
        return /\bPCP\b/.test(t) && /\bPDE\b/.test(t) && /\bFIN\b/.test(t);
    }
    // Acha um elemento clicável (link/imagem/onclick) PERTO de uma referência (o "Mov")
    function clicavelPerto(ref, raio) {
        const rr = ref.getBoundingClientRect(); const cx = rr.left + rr.width / 2, cy = rr.top + rr.height / 2;
        const cands = document.querySelectorAll("a, img, input[type=image], [onclick]");
        let best = null, bd = 1e9;
        for (let i = 0; i < cands.length; i++) {
            const c = cands[i]; if (c === ref) continue;
            const r = c.getBoundingClientRect(); if (!r.width || !r.height) continue;
            const x = r.left + r.width / 2, y = r.top + r.height / 2;
            const d = Math.sqrt((x - cx) * (x - cx) + (y - cy) * (y - cy));
            if (d < (raio || 80) && d < bd) { bd = d; best = c; }
        }
        return best;
    }
    // Acha o botão "DS/SP/PA Mov" — é uma IMAGENZINHA. Acha a imagem perto do texto "Mov"/"Orçamento".
    function acharMovBotao() {
        const els = document.querySelectorAll("a, td, div, span, b, img, button");
        let ref = null;
        // 1) referência: texto "DS Mov" / "Mov"
        for (let i = 0; i < els.length; i++) {
            const e = els[i];
            const t = ((e.innerText || e.alt || e.title || "") + "").replace(/\s+/g, " ").trim();
            const r = e.getBoundingClientRect();
            if (!r.width || !r.height) continue;
            if (/^(DS|SP|PA)\s*Mov$/i.test(t) || /^Mov$/i.test(t)) { ref = e; break; }
        }
        // 2) sem "Mov": usa "Orçamento" como referência (o DS fica logo à esquerda dele)
        if (!ref) {
            for (let i = 0; i < els.length; i++) {
                const e = els[i]; const t = ((e.innerText || "") + "").trim();
                if (/^Or[çc]amento$/i.test(t)) { const r = e.getBoundingClientRect(); if (r.width) { ref = e; break; } }
            }
        }
        if (!ref) return null;
        const rr = ref.getBoundingClientRect(); const cx = rr.left + rr.width / 2, cy = rr.top + rr.height / 2;
        // procura a IMAGEM mais próxima da referência (o badge DS)
        const imgs = document.querySelectorAll("img, input[type=image]");
        let best = null, bd = 1e9;
        for (let i = 0; i < imgs.length; i++) {
            const im = imgs[i]; const r = im.getBoundingClientRect(); if (!r.width || !r.height) continue;
            const x = r.left + r.width / 2, y = r.top + r.height / 2;
            const d = Math.sqrt((x - cx) * (x - cx) + (y - cy) * (y - cy));
            if (d < 100 && d < bd) { bd = d; best = im; }
        }
        if (best) return best;
        return clicavelPerto(ref, 100) || ref;
    }
    // ═══ 👀 VIGIA DO LANÇAMENTO (2026-11-09) ═════════════════════════════════════════════════
    // O robô antigo trabalhava "no escuro": marcava o passo como feito ANTES de conferir e só
    // andava quando a página recarregava. Com internet ruim o clique se perdia e o pedido parava
    // no meio (sem o ID do cliente, sem item, ou pulando o 2º item) sem avisar ninguém. Agora:
    //  1. CONFERE na tela antes de avançar: o item só conta quando aparece na lista do pedido
    //     (ou o SPAmov diz "item aceito"). Não apareceu? Lança de novo (até ITEM_MAX_TENT vezes).
    //  2. NUNCA lança o que já está na lista — por isso pode repetir sem medo de dobrar item.
    //  3. Um VIGIA (setInterval) roda à parte e não depende da página recarregar: passo parado
    //     há mais de 25s (45s esperando o ✓) é refeito, até VIGIA_MAX vezes por passo.
    //  4. No fim, VISTORIA: compara a lista da tela com o pedido, relança o que faltou e avisa
    //     se algum item entrou repetido.
    const VIGIA_LIMITE_MS = 25000, VIGIA_LIMITE_CLIQUE_MS = 45000, VIGIA_MAX = 4, VIGIA_MAX_TOTAL = 14, ITEM_MAX_TENT = 3;
    const carregadoEm = Date.now();
    let processandoRun = false;

    function normCodigo(c) { return String(c || "").replace(/[^0-9a-z]/gi, "").replace(/^0+/, "").toLowerCase(); }
    // Códigos dos itens JÁ lançados no pedido aberto, contando repetidos. ok=false quando a tabela
    // do pedido não está na tela — aí não dá pra concluir nada (nem que faltou, nem que entrou).
    // Conta cada <td> de código uma vez só: o SPAmov aninha tabelas, e varrer as linhas de fora
    // pegaria o mesmo item duas vezes.
    function itensNaTela() {
        const tabela = acharTabelaItens();
        if (!tabela || colXQuant(tabela) === null) return { ok: false, contagem: new Map() };
        const ignorar = new Set([extrairSpamov(), extrairOrcamento()].filter(Boolean));
        const contagem = new Map();
        tabela.querySelectorAll("td").forEach(function (td) {
            if (td.querySelector("td")) return;
            const mm = (td.innerText || "").trim().match(/^(\d{3,7})$/);
            if (!mm || ignorar.has(mm[1])) return;
            const tr = td.parentElement; if (!tr || !tr.cells) return;
            let nome = "";
            Array.prototype.forEach.call(tr.cells, function (c) { const ct = (c.innerText || "").replace(/\s+/g, " ").trim(); if (/[A-Za-zÀ-Ú]{4,}/.test(ct) && ct.length > nome.length) nome = ct; });
            if (!nome || nome.length > 70 || /[{}=;]|\bfunction\b|https?:/i.test(nome)) return;
            const k = normCodigo(mm[1]);
            contagem.set(k, (contagem.get(k) || 0) + 1);
        });
        return { ok: true, contagem: contagem };
    }
    // Código do cliente do pedido aberto, só quando vem logo depois do rótulo CLIENTE ("[j] 123 - NOME").
    function clienteNaTela() {
        const m = bodyText().match(/CLIENTE[\s\S]{0,60}?\[[jf]\]\s*(\d+[a-z]?)\s*-\s*[^\n\r]*[A-Za-zÀ-Ú]/i);
        return m && normCodigo(m[1]) ? m[1] : "";
    }
    function msgRecusaSpamov() { const msg = bodyText().slice(-900); return /n[ãa]o\s+adicionado|saldo\s+n[ãa]o\s+suporta|n[ãa]o\s+suporta|estoque\s+insuficiente|bloquead/i.test(msg) && !/item\s+aceito/i.test(msg); }
    function msgItemAceito() { return /item\s+aceito/i.test(bodyText().slice(-900)); }
    function nomeDaEtapa(stage, run) {
        if (stage === "novo") return "abrir Novo";
        if (stage === "cliente") return "preencher o cliente " + ((run.pedido && run.pedido.cliente) || "?");
        if (stage === "finalizar") return "confirmar (DS→SP→PA)";
        const itens = (run.pedido && run.pedido.itens) || [];
        const i = Math.min(run.idx || 0, itens.length);
        return "lançar itens (" + i + "/" + itens.length + ")";
    }
    function resumoRun(run) {
        const total = ((run.pedido && run.pedido.itens) || []).length;
        return "Cliente " + ((run.pedido && run.pedido.cliente) || "?") + (run.clienteOk ? " ✓" : "") + " · " + (run.confirmados || []).length + "/" + total + " itens conferidos";
    }

    // 👀 O vigia: roda a cada 4s em todo frame do SPAmov, sem depender de recarregar a página.
    async function vigiarRun() {
        if (processandoRun) return;
        const run = await getRun();
        if (!run || !run.ativo || run.stage === "finalizar") return;
        if (!ehFramePrincipal()) return;
        const stage = run.stage || "itens";
        // só o frame que mostra a tela desta etapa age — senão cada frame faria a sua tentativa
        const temTela = stage === "novo" ? !!acharBotaoNovo()
            : stage === "cliente" ? !!(acharCampoCliente() || acharBotaoNovo())
            : (ehFrameItens() || !!acharCampoCliente());
        if (!temTela) return;
        const parado = Date.now() - (run.ts || 0);
        if (parado < (run.aguardando ? VIGIA_LIMITE_CLIQUE_MS : VIGIA_LIMITE_MS)) return;
        const chave = stage + ":" + (run.idx || 0);
        const n = (run.vigiaChave === chave ? (run.vigiaN || 0) : 0) + 1;
        const nTotal = (run.vigiaTotal || 0) + 1;
        if (n > VIGIA_MAX || nTotal > VIGIA_MAX_TOTAL) {
            await clearRun();
            dlog("🛑 vigia: " + nomeDaEtapa(stage, run) + " não andou depois de " + (n > VIGIA_MAX ? VIGIA_MAX + " tentativas" : VIGIA_MAX_TOTAL + " tentativas no pedido") + " — parei");
            statusBox()("🛑 Travou em: " + nomeDaEtapa(stage, run) + ". Já tentei de novo várias vezes. " + resumoRun(run) + ". Confira a tela e termine na mão.");
            return;
        }
        // Trava entre frames: cada um assina e quem continuar dono depois de 400ms age.
        const eu = Math.random().toString(36).slice(2);
        await setRun(Object.assign({}, run, { ts: Date.now(), vigiaChave: chave, vigiaN: n, vigiaTotal: nTotal, vigiaDono: eu }));
        await sleep(400);
        const r2 = await getRun();
        if (!r2 || !r2.ativo || r2.vigiaDono !== eu) return;
        dlog("👀 vigia: " + nomeDaEtapa(stage, run) + " parada há " + Math.round(parado / 1000) + "s — refazendo (" + n + "/" + VIGIA_MAX + ")");
        statusBox()("👀 Demorou demais — refazendo: " + nomeDaEtapa(stage, run) + " (" + n + "/" + VIGIA_MAX + ")");
        processarRun({ vigia: true });
    }

    async function processarRun(opts) {
        if (processandoRun) return;
        processandoRun = true;
        try { await processarRunPasso(opts || {}); }
        catch (e) { dlog("❌ ERRO: " + (e && e.message ? e.message : e)); }
        finally { processandoRun = false; }
    }

    async function processarRunPasso(opts) {
        const run = await getRun();
        if (!run || !run.ativo) { return; }
        if (!ehFramePrincipal()) { dlog("(frame ignorado — sem UI do SPAmov)"); return; }
        // ⏳ 8 min sem progresso (era 2min) — cada item recarrega a página inteira do SPAmov, e com
        // internet lenta isso pode demorar bem mais que 2min; 2min descartava o pedido todo no meio do
        // lançamento (itens que ainda faltavam ficavam pra trás sem aviso nenhum).
        if (Date.now() - (run.ts || 0) > 8 * 60 * 1000) { await clearRun(); dlog("⏰ expirou (8min sem progresso) — limpei"); statusBox()("⏰ O lançamento ficou 8 min parado e foi cancelado. " + resumoRun(run) + "."); return; }

        const status = statusBox();
        const stage = run.stage || "itens";
        dlog("➡ etapa=" + stage + " idx=" + run.idx + " aguardando=" + run.aguardando + (opts.vigia ? " (vigia)" : ""));
        status("🔄 " + (opts.vigia ? "Refazendo" : "Retomando") + " — etapa: " + nomeDaEtapa(stage, run) + "...");
        await sleep(opts.vigia ? 600 : 1800); // deixa a página assentar após o "pisca"/navegação

        // ETAPA FINAL: clicar DS -> SP -> PA até confirmar o pedido
        if (stage === "finalizar") { await clearRun(); status("✅ Itens lançados! Clique no DP/finalizar você mesmo. 👍"); return; } // DS→SP→PA desativado a pedido

        // ETAPA 1: clicar em "Novo"
        if (stage === "novo") {
            let btn = acharBotaoNovo(), t = 0;
            while (!btn && t < 8) { await sleep(500); btn = acharBotaoNovo(); t++; }
            if (!btn) { dlog("❌ botão Novo NÃO achado"); if (ehFramePrincipal()) status("❌ Não achei o botão 'Novo' — o vigia tenta de novo em instantes."); return; }
            dlog("✓ botão Novo achado — clicando");
            status("Abrindo novo pedido...");
            await setRun(Object.assign({}, run, { stage: "cliente", idx: 0, aguardando: false, ultimoCode: "", ts: Date.now() }));
            clicar(btn);
            return; // a página vai recarregar e a etapa "cliente" continua sozinha no próximo load
        }

        // ETAPA 2: preencher o cliente, CONFERIR que o SPAmov achou ele, e clicar em "Enviar"
        if (stage === "cliente") {
            status("Aguardando a tela do cliente...");
            await sleep(1000); // ⏱️ folga após o "Novo" (a tela termina de abrir e foca o campo)
            // Seleciona Jurídica (CNPJ) ou Física (CPF) ANTES de digitar o ID
            const tipo = run.pedido.tipoPessoa || "juridica";
            const tipoSel = selecionarTipoPessoa(tipo);
            dlog("tipo pessoa: " + tipo + " -> " + (tipoSel || "select NÃO achado"));
            await sleep(600);
            // acha o campo do ID (após mudar o tipo, o foco pode ter saído do campo)
            let cli = acharCampoCliente();
            if (!cli) { const ae = document.activeElement; if (ae && ae.tagName === "INPUT" && ae.type !== "checkbox" && ae.type !== "radio") cli = ae; }
            dlog("campo cliente: " + (cli ? "achado" : "NÃO achado"));
            if (!cli) {
                // 🔁 O "Novo" não pegou (a tela continua a de antes): volta um passo e clica de novo.
                if (opts.vigia && acharBotaoNovo()) {
                    dlog("vigia: o campo do cliente não apareceu — clicando em Novo de novo");
                    await setRun(Object.assign({}, run, { stage: "novo", ts: Date.now() }));
                    return processarRunPasso({ vigia: true });
                }
                if (ehFramePrincipal()) status("❌ Não achei o campo do Cliente — o vigia tenta de novo em instantes.");
                return;
            }
            // Digita e CONFERE que o nome do cliente apareceu (até 3 vezes). Antes bastava "a página
            // mudou" — e com internet ruim o pedido seguia sem o cliente.
            const alvo = normCodigo(run.pedido.cliente);
            let achou = false;
            for (let t = 1; t <= 3 && !achou; t++) {
                status("Digitando cliente " + run.pedido.cliente + (t > 1 ? " (tentativa " + t + "/3)" : "") + "...");
                const antesNome = bodyText();
                typeInto(cli, run.pedido.cliente);   // digitação robusta (native setter + execCommand)
                dlog("valor no campo após digitar: '" + (cli.value || "") + "'");
                // 🔑 dispara o "saiu do campo" pra o SPAmov buscar e MOSTRAR o nome do cliente (AJAX).
                // No Android isso só acontecia quando o usuário tocava na tela; agora forçamos no robô.
                blurDe(cli);
                enter(cli);
                status("Buscando o nome do cliente " + run.pedido.cliente + "...");
                const mudou = await esperar(function () { return normCodigo(clienteNaTela()) === alvo || bodyText() !== antesNome; }, 8000);
                await sleep(900); // folga extra pro AJAX assentar
                const naTela = clienteNaTela();
                // Se o SPAmov mostra "[j] código - nome", o código tem que bater. Se não mostra nesse
                // formato, vale o critério antigo (a página mudou) com o campo ainda com o ID certo.
                achou = naTela ? normCodigo(naTela) === alvo : (mudou && normCodigo(cli.value) === alvo);
                dlog("cliente (tentativa " + t + "): " + (naTela ? "na tela " + naTela : (mudou ? "página mudou" : "nada mudou")) + " · campo='" + (cli.value || "") + "' -> " + (achou ? "OK" : "não confirmado"));
                if (!achou) { await sleep(800); cli = acharCampoCliente() || cli; }
            }
            if (!achou && normCodigo(cli.value) !== alvo) {
                status("❌ O ID " + run.pedido.cliente + " não ficou no campo — o vigia tenta de novo em instantes.");
                return; // sem ts novo: o vigia refaz esta etapa
            }
            await setRun(Object.assign({}, run, { stage: "itens", idx: 0, aguardando: false, ultimoCode: "", clienteOk: achou, ts: Date.now() }));
            let env = acharBotaoEnviar(), te = 0;
            while (!env && te < 8) { await sleep(400); env = acharBotaoEnviar(); te++; }
            dlog("botão Enviar: " + (env ? "achado — clicando" : "NÃO achado (tento Enter)"));
            if (env) { status("Clicando em Enviar..."); clicar(env); }
            else { status("Botão Enviar não achado — tentando Enter..."); enter(cli); }
            return; // recarrega -> a etapa "itens" continua sozinha no próximo load
        }

        // ETAPA 3: itens
        if (!ehFrameItens()) {
            // 🔁 O "Enviar" do cliente não pegou: a tela ainda é a do cliente. Volta e refaz.
            if (opts.vigia && acharCampoCliente()) {
                dlog("vigia: a lista de itens não abriu — voltando pro cliente");
                await setRun(Object.assign({}, run, { stage: "cliente", ts: Date.now() }));
                return processarRunPasso({ vigia: true });
            }
            return; // só o frame de itens age aqui
        }
        const itens = run.pedido.itens;
        const total = itens.length;
        const confirmados = (run.confirmados || []).slice();
        const naoConferidos = (run.naoConferidos || []).slice();
        let idx = run.idx || 0;
        let tentItem = run.tentItem || 0;
        const quantasVezes = function (lista, k) { return lista.filter(function (c) { return c === k; }).length; };

        // 🧍 Cliente certo? Lançar item no cliente errado é pior que parar.
        const cliTela = clienteNaTela();
        if (cliTela && run.pedido.cliente && normCodigo(cliTela) !== normCodigo(run.pedido.cliente)) {
            await clearRun();
            dlog("🛑 cliente na tela = " + cliTela + ", mas o pedido é do " + run.pedido.cliente + " — parei");
            status("🛑 O pedido aberto é do cliente " + cliTela + ", não do " + run.pedido.cliente + ". Parei pra não lançar no cliente errado.");
            return;
        }

        // Confere o resultado do último ✓ (na página recarregada, ou na mesma se o vigia chamou)
        if (run.aguardando && run.ultimoCode) {
            const tela = itensNaTela();
            const recarregou = carregadoEm > (run.cliqueTs || 0);
            const k = normCodigo(run.ultimoCode);
            const entrou = (tela.ok && (tela.contagem.get(k) || 0) > quantasVezes(confirmados, k)) || (recarregou && msgItemAceito());
            if (entrou) {
                confirmados.push(k); tentItem = 0;
                dlog("✅ conferido na lista: " + run.ultimoCode);
            } else if (msgRecusaSpamov()) {
                await clearRun();
                status("🛑 PAROU no item " + run.ultimoCode + ". O SPAmov recusou (veja a faixa azul). Os anteriores foram lançados.");
                return;
            } else if (tela.ok && confirmados.every(function (c) { return tela.contagem.has(c); })) {
                // a lista está legível (os anteriores aparecem) e este não: não entrou mesmo
                tentItem++;
                if (tentItem > ITEM_MAX_TENT) {
                    await clearRun();
                    dlog("🛑 " + run.ultimoCode + " não entrou depois de " + ITEM_MAX_TENT + " tentativas — parei");
                    status("🛑 O item " + run.ultimoCode + " não entrou depois de " + ITEM_MAX_TENT + " tentativas. " + resumoRun(Object.assign({}, run, { confirmados: confirmados })) + ". Lance o resto na mão.");
                    return;
                }
                idx = Math.max(0, idx - 1);
                dlog("🔁 " + run.ultimoCode + " não apareceu na lista — lançando de novo (" + tentItem + "/" + ITEM_MAX_TENT + ")");
            } else {
                naoConferidos.push(k);
                dlog("⚠️ não consegui ler a lista pra conferir " + run.ultimoCode + " — sigo e confiro na vistoria do fim");
            }
        }

        // ⏭️ Pula o que já está na lista: repetir um passo nunca dobra item.
        const telaAgora = itensNaTela();
        while (idx < total && telaAgora.ok) {
            const k = normCodigo(itens[idx].code);
            const precisa = quantasVezes(itens.slice(0, idx + 1).map(function (it) { return normCodigo(it.code); }), k);
            if ((telaAgora.contagem.get(k) || 0) < precisa) break;
            if (quantasVezes(confirmados, k) < precisa) confirmados.push(k);
            dlog("⏭️ " + itens[idx].code + " já está na lista — pulo");
            idx++; tentItem = 0;
        }

        if (idx >= total) {
            if (run.pedido && run.pedido.conferenciaPrecos) {
                dlog("✓ todos os " + total + " itens de conferência carregados — aguardando leitura dos preços");
                await clearRun();
                try { chrome.storage.local.get(["friganso_conferencia_ativa"], function (r) { const c = r && r.friganso_conferencia_ativa; if (!c) return; c.pronto = true; c.ts = Date.now(); chrome.storage.local.set({ friganso_conferencia_ativa: c }, mostrarBotaoConferenciaPrecos); }); } catch (e) {}
                status("✅ Itens carregados! Confira a condição À Vista e clique em “Atualizar preços no Prumo”.");
                return;
            }
            // 🔎 VISTORIA: a lista da tela bate com o pedido?
            const fim = itensNaTela();
            if (fim.ok) {
                const pedidoCont = new Map(), original = new Map();
                itens.forEach(function (it) { const k = normCodigo(it.code); pedidoCont.set(k, (pedidoCont.get(k) || 0) + 1); original.set(k, String(it.code)); });
                const faltam = [], dobrados = [];
                pedidoCont.forEach(function (n, k) { const t = fim.contagem.get(k) || 0; if (t < n) faltam.push(original.get(k)); else if (t > n) dobrados.push(original.get(k)); });
                if (faltam.length && (run.rodadasVistoria || 0) < 2) {
                    dlog("🔎 vistoria: faltou " + faltam.join(", ") + " — lançando de novo");
                    status("🔎 Vistoria: faltou " + faltam.join(", ") + " — lançando de novo...");
                    await setRun(Object.assign({}, run, { idx: 0, aguardando: false, ultimoCode: "", confirmados: [], naoConferidos: [], tentItem: 0, rodadasVistoria: (run.rodadasVistoria || 0) + 1, ts: Date.now() }));
                    return processarRunPasso({ vigia: true });
                }
                await clearRun();
                if (faltam.length) { dlog("⚠️ vistoria: ainda falta " + faltam.join(", ")); status("⚠️ Vistoria: faltou " + faltam.join(", ") + " na lista mesmo depois de tentar de novo. Lance na mão antes do DP."); }
                else if (dobrados.length) { dlog("⚠️ vistoria: repetido " + dobrados.join(", ")); status("⚠️ Vistoria: tudo entrou, mas " + dobrados.join(", ") + " está repetido na lista. Apague o repetido antes do DP."); }
                else { dlog("✅ vistoria OK — " + total + "/" + total + " itens na lista"); status("✅ Vistoria OK: cliente " + run.pedido.cliente + " e " + total + "/" + total + " itens conferidos na lista. Agora clique no DP/finalizar. 👍"); }
                return;
            }
            dlog("✓ todos os " + total + " itens lançados — PRONTO (lista não legível pra vistoria)");
            await clearRun();
            status("✅ Itens lançados! Não consegui ler a lista pra conferir — confira e clique no DP/finalizar você mesmo. 👍");
            return;
        }

        // garante a linha de entrada pronta
        let info = camposEntrada(), tent = 0;
        while ((!info || !info.code || !info.qty) && tent < 12) { await sleep(500); info = camposEntrada(); tent++; }
        if (!info || !info.code || !info.qty) {
            // guarda o que já foi conferido, mas sem ts novo: o vigia refaz se a linha não aparecer
            await setRun(Object.assign({}, run, { idx: idx, aguardando: false, confirmados: confirmados, naoConferidos: naoConferidos, tentItem: tentItem }));
            dlog("campos do item ainda não prontos (inputs: " + (info ? info.n : 0) + ") — aguardo e tento de novo");
            status("Aguardando os campos do item... (pode deixar, não precisa tocar na tela)");
            return;
        }

        const it = itens[idx];
        const resumo = resumoRun(Object.assign({}, run, { confirmados: confirmados }));
        dlog("item " + (idx + 1) + "/" + total + ": " + it.code + " x" + it.qty + (tentItem ? " (de novo " + tentItem + "/" + ITEM_MAX_TENT + ")" : ""));
        status("Lançando " + (idx + 1) + "/" + total + ":  " + it.code + "  x" + it.qty + (tentItem ? " (de novo " + tentItem + "/" + ITEM_MAX_TENT + ")" : "") + " · " + resumo);

        // 1) código -> resolve o produto (com blur forçado, igual ao cliente, pro Android)
        const antesCod = bodyText();
        setInput(info.code, "");
        setInput(info.code, it.code);
        blurDe(info.code);
        enter(info.code);
        await esperar(function () { return bodyText() !== antesCod; }, 6000);
        await sleep(900);

        // 2) quantidade (ignora o campo de valor) — e confere que ficou
        info = camposEntrada();
        if (info && info.qty) {
            setInput(info.qty, it.qty);
            if (String(info.qty.value || "").trim() !== String(it.qty)) { await sleep(300); setInput(info.qty, it.qty); }
        }
        await sleep(400);

        // 3) salva o avanço ANTES de clicar (a página vai recarregar). aguardando=true: o próximo
        //    passo só conta este item depois de VER ele na lista.
        const kIt = normCodigo(it.code);
        const antesNaLista = telaAgora.ok ? (telaAgora.contagem.get(kIt) || 0) : 0;
        await setRun(Object.assign({}, run, { stage: "itens", idx: idx + 1, aguardando: true, ultimoCode: it.code, confirmados: confirmados, naoConferidos: naoConferidos, tentItem: tentItem, cliqueTs: Date.now(), ts: Date.now() }));

        // 4) clica no ✓ verde -> o site recarrega e o próximo item continua sozinho
        // ⚠️ Mede a linha DE NOVO agora: digitar a quantidade foca o campo e a tela rola (no celular,
        // com a página em 1280px, sempre). Com a posição velha o ✓ "sumia", o robô apertava Enter no
        // lugar e o item às vezes não entrava.
        const infoAgora = camposEntrada() || info;
        let check = acharCheckVerde(infoAgora ? infoAgora.rect : linhaEntradaRect());
        if (!check) { await sleep(500); const i2 = camposEntrada(); check = acharCheckVerde(i2 ? i2.rect : linhaEntradaRect()); }
        dlog("✓ verde: " + (check ? "achado — clicando" : "NÃO achado (Enter)"));
        if (check) clicar(check);
        else if (infoAgora && infoAgora.qty) enter(infoAgora.qty);
        status("✓ " + it.code + " enviado — conferindo se entrou na lista...");
        // Se o SPAmov colocar o item SEM recarregar a página, segue daqui mesmo em vez de esperar o vigia.
        const apareceu = await esperar(function () { const t = itensNaTela(); return t.ok && (t.contagem.get(kIt) || 0) > antesNaLista; }, 15000);
        if (apareceu) return processarRunPasso({});
        // senão: a página recarrega ("pisca") e o próximo item continua sozinho no próximo load,
        // ou o vigia refaz o passo se nada acontecer.
    }

    function removerDaFila(id) {
        chrome.storage.local.get(["friganso_fila"], function (r) {
            const fila = ((r && r.friganso_fila) || []).filter(function (x) { return x.id !== id; });
            chrome.storage.local.set({ friganso_fila: fila });
        });
    }
    function lancarDaFila(p) {
        // NÃO remove da fila — fica salvo pra você reusar/reenviar (remova manualmente com ✕)
        limparLog();
        dlog("▶ INÍCIO — cliente " + (p.cliente || "?") + ", " + (p.itens ? p.itens.length : 0) + " itens");
        statusBox()("Iniciando lançamento do cliente " + (p.cliente || "?") + "...");
        clearRun().then(function () {
            setRun({ pedido: { cliente: p.cliente, itens: p.itens }, stage: "novo", idx: 0, ativo: true, aguardando: false, ultimoCode: "", ts: Date.now() }).then(processarRun);
        });
    }
    function abrirPopupFila() {
        chrome.storage.local.get(["friganso_fila"], function (r) {
            const fila = (r && r.friganso_fila) || [];
            const old = document.getElementById("friganso-popup"); if (old) old.remove();
            const ov = document.createElement("div"); ov.id = "friganso-popup";
            Object.assign(ov.style, { position: "fixed", inset: "0", background: "rgba(15,23,42,.6)", zIndex: "2147483647", display: "flex", alignItems: "center", justifyContent: "center", fontFamily: "system-ui,sans-serif" });
            ov.addEventListener("click", function (e) { if (e.target === ov) ov.remove(); });
            const box = document.createElement("div");
            Object.assign(box.style, { background: "#fff", borderRadius: "16px", padding: "18px", width: "440px", maxWidth: "92vw", maxHeight: "80vh", overflow: "auto", boxShadow: "0 10px 40px rgba(0,0,0,.4)" });
            const titulo = document.createElement("div"); titulo.textContent = "🚀 Pedidos para lançar"; Object.assign(titulo.style, { fontWeight: "800", fontSize: "16px", color: "#0f172a", marginBottom: "6px" });
            box.appendChild(titulo);
            if (!fila.length) {
                const vazio = document.createElement("div"); vazio.style.cssText = "color:#64748b;font-size:13px;padding:14px 0;line-height:1.5;";
                vazio.innerHTML = 'Nenhum pedido na fila.<br>No app, vá em <b>Fazer Pedido</b>, monte e toque em <b>Mandar pra Extensão</b>.';
                box.appendChild(vazio);
            }
            fila.slice().reverse().forEach(function (p) {
                const card = document.createElement("div");
                Object.assign(card.style, { border: "1px solid #e2e8f0", borderRadius: "12px", padding: "10px", margin: "8px 0", display: "flex", gap: "10px", alignItems: "center" });
                const info = document.createElement("div"); info.style.flex = "1"; info.style.minWidth = "0";
                info.innerHTML = '<div style="font-weight:700;color:#0f172a;font-size:14px;">Cliente ' + (p.cliente || "?") + '</div><div style="color:#64748b;font-size:12px;line-height:1.4;">' + p.itens.length + ' item(ns): ' + p.itens.map(function (i) { return i.code + "×" + i.qty; }).join(", ") + '</div>';
                const btnL = document.createElement("button"); btnL.textContent = "Lançar"; Object.assign(btnL.style, { background: "#15803d", color: "#fff", border: "none", borderRadius: "8px", padding: "8px 14px", fontWeight: "700", cursor: "pointer", flexShrink: "0" });
                btnL.addEventListener("click", function () { ov.remove(); lancarDaFila(p); });
                const btnX = document.createElement("button"); btnX.textContent = "✕"; btnX.title = "Remover da fila"; Object.assign(btnX.style, { background: "#f1f5f9", color: "#64748b", border: "none", borderRadius: "8px", padding: "8px 10px", cursor: "pointer", flexShrink: "0" });
                btnX.addEventListener("click", function () { removerDaFila(p.id); card.remove(); });
                card.appendChild(info); card.appendChild(btnL); card.appendChild(btnX);
                box.appendChild(card);
            });
            const fechar = document.createElement("button"); fechar.textContent = "Fechar"; Object.assign(fechar.style, { marginTop: "8px", background: "#e2e8f0", color: "#334155", border: "none", borderRadius: "8px", padding: "9px 12px", cursor: "pointer", width: "100%", fontWeight: "700" });
            fechar.addEventListener("click", function () { ov.remove(); });
            box.appendChild(fechar);
            ov.appendChild(box); document.body.appendChild(ov);
        });
    }
    function cancelarLancamento() { try { chrome.storage.local.remove("friganso_conferencia_ativa"); } catch (e) {} clearRun().then(function () { statusBox()("Lançamento cancelado."); }); }

    // ---------- 🪜 ETAPAS (retomar de um ponto específico) ----------
    // O lançamento tem 4 fases (login → menu Vendas → Novo+Cliente → itens) e cada uma recarrega o
    // SPAmov inteiro. Quando algo sai do trilho no meio (internet caiu, o site deslogou, a tela voltou
    // pro lugar errado), antes só dava pra recomeçar tudo do zero. Aqui cada fase vira um botão que
    // força a partir dali — inclusive retomando os itens do ponto onde parou, sem repetir o que já foi.
    function forcarEtapaLogin() {
        const status = statusBox();
        if (!document.querySelector("input[type=password]")) { status("ℹ️ Você já está logado (não é a tela de login). Pule pra etapa 2."); return; }
        chrome.storage.local.get(["friganso_creds"], function (c) {
            const cr = (c && c.friganso_creds) || {};
            if (!cr.usuario || !cr.senha) { status("⚠️ Não tem login salvo. Salve seu usuário/senha do SPAmov na aba 🐞 Debug do app."); return; }
            chrome.storage.local.set({ friganso_creds: { usuario: cr.usuario, senha: cr.senha, autoLogin: true, irVendas: false } }, function () {
                status("1️⃣ Fazendo o login...");
                tentarLogin();
            });
        });
    }
    function forcarEtapaVendas() {
        const status = statusBox();
        if (document.querySelector("input[type=password]")) { status("⚠️ Ainda está na tela de login — faça a etapa 1 primeiro."); return; }
        chrome.storage.local.get(["friganso_creds"], function (c) {
            const cr = (c && c.friganso_creds) || {};
            chrome.storage.local.set({ friganso_creds: { usuario: cr.usuario || "", senha: cr.senha || "", autoLogin: false, irVendas: true } }, function () {
                status("2️⃣ Abrindo VENDAS - VENDEDOR...");
                tentarNavegarVendas();
            });
        });
    }
    function forcarEtapaCliente(p) {
        limparLog();
        dlog("🪜 etapa forçada: Novo + Cliente — cliente " + (p.cliente || "?"));
        statusBox()("3️⃣ Abrindo 'Novo' e preenchendo o cliente " + (p.cliente || "?") + "...");
        clearRun().then(function () {
            setRun({ pedido: p, stage: "novo", idx: 0, ativo: true, aguardando: false, ultimoCode: "", ts: Date.now() }).then(processarRun);
        });
    }
    function forcarEtapaItens(p, idx) {
        const total = (p.itens || []).length;
        limparLog();
        dlog("🪜 etapa forçada: itens a partir do " + (idx + 1) + "/" + total);
        statusBox()("4️⃣ Lançando os itens a partir do " + (idx + 1) + "º (" + (total - idx) + " restante(s))...");
        clearRun().then(function () {
            setRun({ pedido: p, stage: "itens", idx: idx, ativo: true, aguardando: false, ultimoCode: "", ts: Date.now() }).then(processarRun);
        });
    }

    function abrirPopupEtapas() {
        chrome.storage.local.get(["friganso_fila"], function (r) {
            const fila = (r && r.friganso_fila) || [];
            let escolhido = fila.length ? fila[fila.length - 1] : null; // o mais recente que você mandou
            const old = document.getElementById("friganso-popup"); if (old) old.remove();
            const ov = document.createElement("div"); ov.id = "friganso-popup";
            Object.assign(ov.style, { position: "fixed", inset: "0", background: "rgba(15,23,42,.6)", zIndex: "2147483647", display: "flex", alignItems: "center", justifyContent: "center", fontFamily: "system-ui,sans-serif" });
            ov.addEventListener("click", function (e) { if (e.target === ov) ov.remove(); });
            const box = document.createElement("div");
            Object.assign(box.style, { background: "#fff", borderRadius: "16px", padding: "18px", width: "460px", maxWidth: "94vw", maxHeight: "86vh", overflow: "auto", boxShadow: "0 10px 40px rgba(0,0,0,.4)" });

            const titulo = document.createElement("div"); titulo.textContent = "🪜 Etapas do pedido";
            Object.assign(titulo.style, { fontWeight: "800", fontSize: "16px", color: "#0f172a" });
            box.appendChild(titulo);
            const sub = document.createElement("div"); sub.textContent = "Travou no meio? Force a partir da etapa certa — sem recomeçar tudo.";
            Object.assign(sub.style, { color: "#64748b", fontSize: "12px", margin: "3px 0 12px", lineHeight: "1.4" });
            box.appendChild(sub);

            // Escolha do pedido (as etapas 3 e 4 precisam saber cliente/itens)
            const areaSel = document.createElement("div"); box.appendChild(areaSel);
            // Corpo que muda conforme o pedido escolhido (etapas 3/4 + lista de itens)
            const areaPedido = document.createElement("div"); box.appendChild(areaPedido);

            function linhaEtapa(num, titulo2, desc, corBtn, onClick, habilitado) {
                const row = document.createElement("div");
                Object.assign(row.style, { border: "1px solid #e2e8f0", borderRadius: "12px", padding: "10px", margin: "8px 0", display: "flex", gap: "10px", alignItems: "center" });
                const info = document.createElement("div"); info.style.flex = "1"; info.style.minWidth = "0";
                info.innerHTML = '<div style="font-weight:700;color:#0f172a;font-size:14px;">' + num + ' ' + titulo2 + '</div><div style="color:#64748b;font-size:12px;line-height:1.4;">' + desc + '</div>';
                const btn = document.createElement("button"); btn.textContent = "Forçar";
                Object.assign(btn.style, { background: habilitado ? corBtn : "#cbd5e1", color: "#fff", border: "none", borderRadius: "8px", padding: "9px 14px", fontWeight: "700", cursor: habilitado ? "pointer" : "not-allowed", flexShrink: "0" });
                if (habilitado) btn.addEventListener("click", function () { ov.remove(); onClick(); });
                row.appendChild(info); row.appendChild(btn);
                return row;
            }

            // Etapas 1 e 2 não dependem de pedido nenhum
            box.insertBefore(linhaEtapa("1️⃣", "Entrar no site", "Preenche usuário e senha e clica em Log In.", "#0f172a", forcarEtapaLogin, true), areaSel);
            box.insertBefore(linhaEtapa("2️⃣", "Abrir VENDAS - VENDEDOR", "Abre o menu SPAmov e entra na tela de vendas.", "#0f172a", forcarEtapaVendas, true), areaSel);

            function desenharPedido() {
                areaPedido.innerHTML = "";
                if (!escolhido) {
                    const aviso = document.createElement("div");
                    aviso.style.cssText = "color:#92400e;background:#fffbeb;border:1px solid #fde68a;border-radius:12px;padding:12px;font-size:13px;line-height:1.5;margin:8px 0;";
                    aviso.innerHTML = 'As etapas <b>3</b> e <b>4</b> precisam de um pedido. No app, vá em <b>Fazer Pedido</b>, monte o pedido e toque em <b>🚀 Só mandar (site já aberto)</b> — ele aparece aqui.';
                    areaPedido.appendChild(aviso);
                    return;
                }
                const p = escolhido;
                areaPedido.appendChild(linhaEtapa("3️⃣", "Novo pedido + cliente", "Clica em 'Novo' e preenche o cliente " + (p.cliente || "?") + ".", "#15803d", function () { forcarEtapaCliente(p); }, true));
                areaPedido.appendChild(linhaEtapa("4️⃣", "Lançar os itens", "Lança os " + p.itens.length + " itens do começo.", "#15803d", function () { forcarEtapaItens(p, 0); }, true));

                const tit = document.createElement("div");
                tit.innerHTML = '📋 <b>Itens deste pedido</b>';
                Object.assign(tit.style, { fontSize: "13px", color: "#0f172a", margin: "14px 0 2px" });
                areaPedido.appendChild(tit);
                const dica = document.createElement("div");
                dica.textContent = "Se parou no meio, toque em “▶ daqui” pra continuar desse item — os anteriores não são repetidos.";
                Object.assign(dica.style, { color: "#64748b", fontSize: "11px", marginBottom: "6px", lineHeight: "1.4" });
                areaPedido.appendChild(dica);

                p.itens.forEach(function (it, i) {
                    const li = document.createElement("div");
                    Object.assign(li.style, { display: "flex", gap: "8px", alignItems: "center", padding: "7px 9px", border: "1px solid #e2e8f0", borderRadius: "10px", margin: "5px 0" });
                    const txt = document.createElement("div"); txt.style.cssText = "flex:1;min-width:0;font-size:12px;color:#334155;line-height:1.35;";
                    txt.innerHTML = '<b style="color:#0f172a;">' + (i + 1) + '. ' + it.code + '</b> × ' + it.qty + '<br><span style="color:#64748b;">' + ((it.nome || it.name || "") + "").slice(0, 46) + '</span>';
                    const b = document.createElement("button"); b.textContent = "▶ daqui"; b.title = "Lançar a partir deste item";
                    Object.assign(b.style, { background: "#f1f5f9", color: "#0f172a", border: "1px solid #e2e8f0", borderRadius: "8px", padding: "7px 10px", fontSize: "12px", fontWeight: "700", cursor: "pointer", flexShrink: "0" });
                    b.addEventListener("click", function () { ov.remove(); forcarEtapaItens(p, i); });
                    li.appendChild(txt); li.appendChild(b);
                    areaPedido.appendChild(li);
                });
            }

            if (fila.length > 1) {
                const lab = document.createElement("div"); lab.textContent = "Pedido (etapas 3 e 4):";
                Object.assign(lab.style, { fontSize: "12px", fontWeight: "700", color: "#334155", margin: "10px 0 4px" });
                areaSel.appendChild(lab);
                const sel = document.createElement("select");
                Object.assign(sel.style, { width: "100%", padding: "9px", borderRadius: "10px", border: "1px solid #cbd5e1", fontSize: "13px", background: "#fff" });
                fila.slice().reverse().forEach(function (p, i) {
                    const o = document.createElement("option");
                    o.value = String(i);
                    o.textContent = "Cliente " + (p.cliente || "?") + " — " + p.itens.length + " item(ns)";
                    sel.appendChild(o);
                });
                const invertida = fila.slice().reverse();
                sel.addEventListener("change", function () { escolhido = invertida[parseInt(sel.value, 10)] || null; desenharPedido(); });
                areaSel.appendChild(sel);
            }

            desenharPedido();

            const fechar = document.createElement("button"); fechar.textContent = "Fechar";
            Object.assign(fechar.style, { marginTop: "12px", background: "#e2e8f0", color: "#334155", border: "none", borderRadius: "8px", padding: "10px 12px", cursor: "pointer", width: "100%", fontWeight: "700" });
            fechar.addEventListener("click", function () { ov.remove(); });
            box.appendChild(fechar);
            ov.appendChild(box); document.body.appendChild(ov);
        });
    }

    // ---------- LOGIN AUTOMÁTICO ----------
    function acharCampoPorLabel(re, tipo) {
        let labelRect = null;
        const cells = document.querySelectorAll("td, th, label, span, div, b, font");
        for (let i = 0; i < cells.length; i++) {
            const t = (cells[i].innerText || "").trim();
            if (re.test(t) && t.length < 28) { const r = cells[i].getBoundingClientRect(); if (r.width && r.height) { labelRect = r; break; } }
        }
        if (!labelRect) return null;
        const cy = labelRect.top + labelRect.height / 2;
        const inps = Array.prototype.slice.call(document.querySelectorAll("input")).filter(function (inp) {
            const tp = (inp.type || "text").toLowerCase();
            if (tipo && tp !== tipo) return false;
            if (["checkbox", "radio", "hidden", "button", "submit", "image"].indexOf(tp) !== -1) return false;
            const r = inp.getBoundingClientRect();
            return r.width > 20 && r.height > 5 && Math.abs((r.top + r.height / 2) - cy) < 18 && r.left >= labelRect.left;
        });
        inps.sort(function (a, b) { return a.getBoundingClientRect().left - b.getBoundingClientRect().left; });
        return inps[0] || null;
    }
    function acharBotaoTextoExato(re) {
        const els = document.querySelectorAll("input[type=button], input[type=submit], button, a");
        for (let i = 0; i < els.length; i++) { const e = els[i]; const t = ((e.value || e.innerText || "") + "").trim(); if (re.test(t)) { const r = e.getBoundingClientRect(); if (r.width && r.height) return e; } }
        return null;
    }
    function tentarLogin() {
        try {
            chrome.storage.local.get(["friganso_creds"], function (c) {
                const cr = c && c.friganso_creds;
                if (!cr || !cr.autoLogin) return;
                if (!document.querySelector("input[type=password]")) return; // não é a tela de login
                chrome.storage.local.set({ friganso_creds: { usuario: cr.usuario, senha: cr.senha, autoLogin: false, irVendas: cr.irVendas } }); // evita loop, mantém o ir-pra-vendas
                const userInput = acharCampoPorLabel(/Usu[áa]rio/i, "text") || document.querySelector("input[type=text]");
                const passInput = acharCampoPorLabel(/Senha/i, "password") || document.querySelector("input[type=password]");
                dlog("login: campo usuário " + (userInput ? "ok" : "?") + ", senha " + (passInput ? "ok" : "?"));
                if (userInput && cr.usuario) typeInto(userInput, cr.usuario);
                if (passInput && cr.senha) typeInto(passInput, cr.senha);
                setTimeout(function () {
                    const b = acharBotaoTextoExato(/^Log\s*In$/i);
                    dlog("login: botão Log In " + (b ? "achado — clicando" : "NÃO achado"));
                    if (b) clicar(b);
                }, 700);
            });
        } catch (e) {}
    }

    // ---------- NAVEGAR NO MENU (SPA mov -> VENDAS - VENDEDOR) ----------
    // Roda um código no CONTEXTO da página (necessário para javascript: e funções do site)
    function rodarNaPagina(code) {
        try {
            const s = document.createElement("script");
            s.textContent = code;
            (document.head || document.documentElement).appendChild(s);
            if (s.parentNode) s.parentNode.removeChild(s);
            return true;
        } catch (e) { return false; }
    }
    // Aciona UMA VEZ: se tem onclick/javascript:, roda na página (1x); senão dá 1 clique nativo.
    // (não usa o clicar() normal aqui pra NÃO disparar a ação 2x e "destogglar" o menu)
    function clicarRobusto(el) {
        if (!el) return;
        let p = el, code = null;
        for (let i = 0; i < 4 && p; i++) {
            const oc = p.getAttribute && p.getAttribute("onclick");
            const hr = p.getAttribute && p.getAttribute("href");
            if (oc) { code = oc; break; }
            if (hr && /^javascript:/i.test(hr)) { code = hr.replace(/^javascript:/i, ""); break; }
            p = p.parentElement;
        }
        if (code) { rodarNaPagina("try{" + code + "}catch(e){}"); }
        else { try { el.focus && el.focus(); } catch (e) {} try { el.click(); } catch (e) {} }
    }
    function acharLinkTexto(re) {
        const els = document.querySelectorAll("a, td, span, div, b, font, li");
        for (let i = 0; i < els.length; i++) {
            const e = els[i]; const t = ((e.innerText || "") + "").replace(/\s+/g, " ").trim();
            if (re.test(t) && t.length < 30) { const r = e.getBoundingClientRect(); if (r.width && r.height) return e; }
        }
        return null;
    }
    function acharPorHrefOnclick(sub) {
        const els = document.querySelectorAll("a, [onclick]");
        for (let i = 0; i < els.length; i++) {
            const e = els[i]; const h = ((e.getAttribute("href") || "") + " " + (e.getAttribute("onclick") || "")).toLowerCase();
            if (h.indexOf(sub.toLowerCase()) !== -1) { const r = e.getBoundingClientRect(); if (r.width && r.height) return e; }
        }
        return null;
    }
    function forcarVisivel(el) {
        if (!el) return;
        try { el.style.display = "block"; el.style.visibility = "visible"; el.removeAttribute("hidden"); } catch (e) {}
    }
    // Acha o link "VENDAS - VENDEDOR" (prioriza <a>, depois href de vendedor/spadim)
    function acharLinkVendas() {
        const as = document.querySelectorAll("a");
        for (let i = 0; i < as.length; i++) { const a = as[i]; const t = ((a.innerText || "") + "").replace(/\s+/g, " ").trim(); if (/VENDAS\s*-\s*VENDEDOR/i.test(t)) { const r = a.getBoundingClientRect(); if (r.width && r.height) return a; } }
        for (let i = 0; i < as.length; i++) { const a = as[i]; const h = ((a.getAttribute("href") || "") + " " + (a.getAttribute("onclick") || "")).toLowerCase(); if (/vendedorexterno|spa\.vended|vended/.test(h)) { const r = a.getBoundingClientRect(); if (r.width && r.height) return a; } }
        return acharLinkTexto(/VENDAS\s*-\s*VENDEDOR/i);
    }
    function tentarNavegarVendas() {
        try {
            chrome.storage.local.get(["friganso_creds"], function (c) {
                const cr = c && c.friganso_creds;
                if (!cr || !cr.irVendas) return;
                if (document.querySelector("input[type=password]")) return; // ainda na tela de login
                const span = document.getElementById("spamov");
                const spamovLink = acharPorHrefOnclick("spamov") || acharLinkTexto(/^SPA\s*mov$/i);
                const jaTemVendas = acharLinkTexto(/VENDAS\s*-\s*VENDEDOR/i);
                if (!span && !spamovLink && !jaTemVendas) return; // ainda não é a tela de menu
                chrome.storage.local.set({ friganso_creds: { usuario: cr.usuario, senha: cr.senha, autoLogin: false, irVendas: false } });
                dlog("menu: span#spamov=" + (span ? "ok" : "?") + " linkSPAmov=" + (spamovLink ? "ok" : "?"));
                // força o submenu visível (mais confiável que depender da função do site)
                forcarVisivel(span);
                if (!span && spamovLink) clicarRobusto(spamovLink); // sem o span, tenta a função
                let tentou = 0;
                const iv = setInterval(function () {
                    tentou++;
                    forcarVisivel(document.getElementById("spamov")); // mantém aberto
                    const v = acharLinkVendas();
                    if (v) {
                        dlog("menu: clicando VENDAS - VENDEDOR <" + v.tagName + ">");
                        try { v.focus && v.focus(); } catch (e) {}
                        try { v.click(); } catch (e) {}          // clique NATIVO (navega / executa javascript:)
                        clearInterval(iv);
                    } else if (tentou > 40) { clearInterval(iv); dlog("menu: VENDAS - VENDEDOR não apareceu (manda o log)"); }  // ~16s (era ~6.4s)
                }, 400);
            });
        } catch (e) { dlog("menu ERRO: " + (e && e.message)); }
    }

    // ⚡ Dispara o lançamento sozinho quando chega na tela de vendas (após login + navegação)
    function tentarIniciarAuto() {
        try {
            chrome.storage.local.get(["friganso_run_auto", "friganso_run"], function (r) {
                const auto = r && r.friganso_run_auto;
                if (!auto || !auto.pedido) return;
                // ⏳ 15 min (era 5) — internet lenta pode fazer login+navegação demorar bem mais que isso,
                // e o pedido inteiro era descartado em silêncio se passasse do prazo antigo.
                if (Date.now() - (auto.ts || 0) > 15 * 60 * 1000) { chrome.storage.local.remove("friganso_run_auto"); return; }
                if (r.friganso_run && r.friganso_run.ativo) return;          // já tem lançamento rolando
                if (document.querySelector("input[type=password]")) return;  // ainda na tela de login
                let t = 0;
                const iv = setInterval(function () {
                    t++;
                    if (document.querySelector("input[type=password]")) { clearInterval(iv); return; }
                    const novo = acharBotaoNovo();
                    if (novo) {
                        clearInterval(iv);
                        chrome.storage.local.get(["friganso_run", "friganso_run_auto"], function (r2) {
                            if (r2.friganso_run && r2.friganso_run.ativo) return;   // outro frame já começou
                            if (!r2.friganso_run_auto) return;                       // já foi consumido
                            chrome.storage.local.remove("friganso_run_auto");
                            limparLog();
                            dlog("🤖 auto: tela de vendas pronta — lançando cliente " + (auto.pedido.cliente || "?") + " (" + (auto.pedido.itens ? auto.pedido.itens.length : 0) + " itens)");
                            statusBox()("🤖 Lançando automático: cliente " + (auto.pedido.cliente || "?") + "...");
                            setRun({ pedido: auto.pedido, stage: "novo", idx: 0, ativo: true, aguardando: false, ultimoCode: "", ts: Date.now() }).then(processarRun);
                        });
                    } else if (t > 60) { clearInterval(iv); }  // ~30s (era ~10s) esperando a tela de vendas neste load
                }, 500);
            });
        } catch (e) {}
    }

    // ---------- AÇÕES DO NAVEGADOR ANDROID ----------
    // Barra da PÁGINA, atualizável por OTA; não altera a barra Java do APK.
    function instalarBarraAndroid() {
        if (!ehNavegadorAndroid()) return;
        window.__frigMobileActions = {
            tabela: function () { return ehTelaListaPrecos() ? extrairListaPrecos() : []; },
            pedido: function () { return montarPedidoLeitura(true); },
            login: function () { if (!document.querySelector('input[type=password]')) return false; forcarEtapaLogin(); return true; }
        };
        // Frames internos apenas fornecem dados. A barra visual pertence à página principal de
        // cada janela do Android, o que evita sobreposição e a mantém ao abrir um pedido.
        if (window !== window.top || !document.body) return;
        // O script pode ser reinjetado depois de navegações e reconexões. Preserve a barra
        // existente para não acumular painéis, timers e eventos no mesmo documento.
        const existente = document.getElementById('friganso-mobile-toolbar');
        if (existente) {
            existente.style.display = 'block';
            return;
        }
        const barra = document.createElement('div');
        barra.id = 'friganso-mobile-toolbar';
        barra.setAttribute('role', 'region');
        barra.setAttribute('aria-label', 'Ações do Prumo ERP');
        Object.assign(barra.style, { position: 'fixed', zIndex: '2147483647', boxSizing: 'border-box', padding: '7px', border: '1px solid rgba(167,139,250,.38)', borderRadius: '16px', background: 'linear-gradient(145deg,rgba(16,16,22,.98),rgba(8,13,18,.98))', color: '#f5f5f7', fontFamily: 'system-ui,sans-serif', boxShadow: '0 18px 55px rgba(0,0,0,.55),0 0 28px rgba(124,108,255,.14)', transformOrigin: 'top left', backdropFilter: 'blur(18px)', overflow: 'hidden' });
        const acoes = document.createElement('div');
        Object.assign(acoes.style, { display: 'none', gridTemplateColumns: '1fr 1fr', gap: '7px', marginTop: '7px' });
        const aviso = document.createElement('div');
        aviso.setAttribute('role', 'status');
        Object.assign(aviso.style, { display: 'none', fontSize: '12px', lineHeight: '1.4', marginTop: '7px', padding: '8px 10px', borderRadius: '10px', background: 'rgba(255,255,255,.06)', color: '#c9c9d1' });
        const avisar = txt => {
            aviso.textContent = txt || '';
            aviso.style.display = txt ? 'block' : 'none';
        };
        const visitar = () => {
            const partes = [];
            function ler(w) {
                try {
                    if (w.document.body && w.document.body.tagName !== 'FRAMESET' && w.innerWidth > 0 && w.innerHeight > 0) partes.push(w);
                    for (let i = 0; i < w.frames.length; i++) ler(w.frames[i]);
                } catch (e) { /* frame de outra origem: sem acesso */ }
            }
            try { ler(window.top); } catch (e) {}
            if (!partes.includes(window)) partes.push(window);
            return partes;
        };
        const adicionar = (rotulo, fn, cor) => {
            const btn = document.createElement('button');
            btn.type = 'button'; btn.textContent = rotulo;
            Object.assign(btn.style, { minHeight: '48px', padding: '8px 10px', border: '1px solid rgba(255,255,255,.10)', borderRadius: '11px', font: '700 13px system-ui,sans-serif', background: cor || '#1a1a24', color: '#f7f7fa', cursor: 'pointer', boxShadow: 'inset 0 1px rgba(255,255,255,.05)' });
            btn.addEventListener('click', () => { try { avisar(''); fn(); } catch (e) { avisar('Não foi possível concluir. Tente novamente: ' + (e.message || e)); } });
            acoes.appendChild(btn); return btn;
        };
        const titulo = document.createElement('button');
        titulo.type = 'button'; titulo.textContent = '✦  PRUMO · abrir ações';
        titulo.setAttribute('aria-expanded', 'false');
        Object.assign(titulo.style, { width: '100%', minHeight: '46px', padding: '0 13px', border: '1px solid rgba(124,108,255,.25)', borderRadius: '11px', background: 'linear-gradient(110deg,#211a37,#12232b)', color: '#fff', font: '800 13px system-ui,sans-serif', letterSpacing: '.02em', cursor: 'pointer', textAlign: 'left' });
        titulo.onclick = () => {
            const aberto = acoes.style.display === 'none';
            acoes.style.display = aberto ? 'grid' : 'none';
            aviso.style.display = aberto && aviso.textContent ? 'block' : 'none';
            titulo.textContent = aberto ? '✦  PRUMO · recolher ações' : '✦  PRUMO · abrir ações';
            titulo.setAttribute('aria-expanded', String(aberto));
        };
        adicionar('📥 Enviar tabela', () => {
            const produtos = new Map();
            visitar().forEach(w => { if (w.__frigMobileActions) w.__frigMobileActions.tabela().forEach(p => produtos.set(String(p.code), p)); });
            if (!produtos.size) { avisar('Abra a Lista de Preços e carregue os produtos antes de enviar.'); return; }
            retornarAoAndroid({ frigansoRetorno: 1, tipo: 'tabela', produtos: Array.from(produtos.values()) });
        }, 'linear-gradient(135deg,#7c6cff,#5b4ce8)');
        adicionar('📋 Enviar resumo', () => {
            const pedido = { cliente: '', clienteNome: '', spamov: '', condicaoPagamento: '', itens: [] }, vistos = new Set();
            visitar().forEach(w => {
                if (!w.__frigMobileActions) return;
                const p = w.__frigMobileActions.pedido();
                ['cliente', 'clienteNome', 'spamov', 'condicaoPagamento'].forEach(k => { if (!pedido[k] && p[k]) pedido[k] = p[k]; });
                (p.itens || []).forEach(it => { if (!vistos.has(String(it.code))) { vistos.add(String(it.code)); pedido.itens.push(it); } });
            });
            if (!pedido.itens.length) { avisar('Abra o pedido com a lista de itens antes de enviar o resumo.'); return; }
            retornarAoAndroid(pedido);
        }, 'linear-gradient(135deg,#0891b2,#0e7490)');
        adicionar('🔑 Login salvo', () => {
            if (!visitar().some(w => w.__frigMobileActions && w.__frigMobileActions.login())) avisar('Você já está logado ou a tela de login ainda não abriu.');
            else avisar('Login solicitado. Se faltarem credenciais, cadastre o seu login em Minha conta, no Prumo.');
        });
        adicionar('↩ Voltar ao ERP', () => retornarAoAndroid({ frigansoRetorno: 1, tipo: 'voltar' }));
        barra.append(titulo, acoes, aviso); document.body.appendChild(barra);
        const posicionar = () => {
            barra.style.display = 'block';
            const v = window.visualViewport;
            const layoutW = Math.max(document.documentElement.clientWidth || 0, window.innerWidth || 0, 360);
            const telaW = Math.max(320, Math.min(screen.width || 360, v ? v.width : 360));
            // O SPAmov usa um viewport antigo de desktop. Compensar essa redução mantém o painel
            // com tamanho de toque real no celular sem alterar a escala da página da empresa.
            const correcao = Math.max(1, Math.min(3, layoutW / telaW));
            const largura = Math.max(250, Math.min(350, telaW - 20));
            barra.style.width = largura + 'px';
            barra.style.transform = 'scale(' + correcao + ')';
            barra.style.left = Math.max(8, layoutW - (largura + 10) * correcao) + 'px';
            barra.style.top = (10 * correcao) + 'px';
        };
        posicionar();
        window.addEventListener('resize', posicionar);
        if (window.visualViewport) { window.visualViewport.addEventListener('resize', posicionar); window.visualViewport.addEventListener('scroll', posicionar); }
        const timer = setInterval(posicionar, 1500);
        window.addEventListener('pagehide', () => clearInterval(timer), { once: true });
    }

    // ---------- CONFERÊNCIA DE PREÇOS EM LOTE ----------
    function coletarDadosPedidoEmTodosFrames() {
        const partes = [];
        function visitar(w) {
            try {
                if (w.__frigDadosFrame) { const d = w.__frigDadosFrame(); if (d) partes.push(d); }
                for (let i = 0; i < w.frames.length; i++) visitar(w.frames[i]);
            } catch (e) {}
        }
        try { visitar(window.top); } catch (e) { visitar(window); }
        const saida = { cliente: "", condicaoPagamento: "", itens: [] }, vistos = new Set();
        partes.forEach(function (p) {
            if (!saida.cliente && p.cliente) saida.cliente = p.cliente;
            if (!saida.condicaoPagamento && p.condicaoPagamento) saida.condicaoPagamento = p.condicaoPagamento;
            (p.itens || []).forEach(function (it) { const code = String(it.code || ""); if (code && !vistos.has(code)) { vistos.add(code); saida.itens.push(it); } });
        });
        return saida;
    }
    function concluirConferenciaPrecos(conf) {
        const dados = coletarDadosPedidoEmTodosFrames();
        if (!/(^|[^a-zà-ú])(?:a|à)\s*vista\b/i.test(dados.condicaoPagamento || "")) {
            alert("A condição de pagamento desta conferência não está como À Vista.\n\nSelecione À Vista no pedido e clique novamente para evitar gravar o preço errado.");
            return;
        }
        const lidos = new Map((dados.itens || []).map(function (it) { return [String(it.code), it]; }));
        const alvo = (conf.pedido && conf.pedido.itens) || [];
        const faltando = [], precos = [];
        alvo.forEach(function (it) {
            const achado = lidos.get(String(it.code));
            const valor = Number(achado && achado.valorUnit) || 0;
            if (!achado || valor <= 0) faltando.push(String(it.code));
            else precos.push({ code: String(it.code), name: (achado.nome || it.nome || ""), valorUnit: valor });
        });
        const salvarResultado = function (itensFinais, excluidos) {
            const entregar = function () {
                try { chrome.storage.local.remove("friganso_conferencia_ativa"); } catch (e) {}
                const url = APP_URL + "?precosConferidos=pendente";
                const ehCelular = (navigator.maxTouchPoints || 0) > 0;
                if (ehCelular) { try { (window.top || window).location.href = url; } catch (e) { window.location.href = url; } return; }
                try { const w = (window.top || window).open(url, "friganso_erp_app"); if (w && w.focus) w.focus(); } catch (e) { window.open(url, "friganso_erp_app"); }
            };
            try {
                chrome.storage.local.set({ friganso_precos_conferidos_pendente: { itens: itensFinais, excluidos: excluidos || [], cliente: conf.cliente || dados.cliente || "", ts: Date.now() } }, entregar);
            } catch (e) { alert("Não consegui guardar as alterações para enviar ao Prumo. Recarregue a extensão e tente de novo."); }
        };
        if (faltando.length) { mostrarDecisaoItensAusentes(conf, faltando, precos, salvarResultado); return; }
        salvarResultado(precos, []);
    }
    function mostrarDecisaoItensAusentes(conf, codigos, precosLidos, concluir) {
        const antigo = document.getElementById("friganso-ausentes-modal"); if (antigo) antigo.remove();
        const alvo = new Map((((conf || {}).pedido || {}).itens || []).map(function (it) { return [String(it.code), it]; }));
        const escolhas = {};
        const ov = document.createElement("div"); ov.id = "friganso-ausentes-modal";
        Object.assign(ov.style, { position: "fixed", inset: "0", zIndex: "2147483647", background: "rgba(2,6,23,.92)", display: "flex", alignItems: "center", justifyContent: "center", padding: "14px", fontFamily: "system-ui,sans-serif" });
        const box = document.createElement("div"); Object.assign(box.style, { width: "620px", maxWidth: "96vw", maxHeight: "92vh", overflow: "hidden", display: "flex", flexDirection: "column", borderRadius: "20px", border: "1px solid rgba(251,191,36,.35)", background: "#0b0d17", color: "#e5e7eb", boxShadow: "0 24px 80px rgba(0,0,0,.65)" });
        const topo = document.createElement("div"); topo.innerHTML = '<div style="font-size:18px;font-weight:900;color:#fef3c7">⚠️ ' + codigos.length + ' produto(s) não apareceram no SPAmov</div><div style="font-size:13px;color:#9ca3af;margin-top:6px;line-height:1.45">Decida o que fazer com cada item. Excluir remove o produto das ofertas e seleções do Prumo em todos os aparelhos. Atualizar mantém o produto com o preço informado.</div>'; Object.assign(topo.style, { padding: "18px", borderBottom: "1px solid #252938" }); box.appendChild(topo);
        const lista = document.createElement("div"); Object.assign(lista.style, { padding: "12px", overflowY: "auto", display: "grid", gap: "10px", background: "#080a12" });
        codigos.forEach(function (code) {
            const item = alvo.get(String(code)) || { code: code, nome: "Produto " + code }; escolhas[code] = { acao: "manual", valor: "" };
            const card = document.createElement("div"); Object.assign(card.style, { border: "1px solid #252938", borderRadius: "14px", padding: "13px", background: "#111420" });
            const nome = document.createElement("div"); nome.textContent = code + "  ·  " + (item.nome || item.name || "Produto sem nome"); Object.assign(nome.style, { fontWeight: "800", fontSize: "13px", marginBottom: "10px", color: "#f3f4f6" }); card.appendChild(nome);
            const linha = document.createElement("div"); Object.assign(linha.style, { display: "grid", gridTemplateColumns: "1fr 1fr", gap: "8px" });
            const manual = document.createElement("button"); manual.type = "button"; manual.textContent = "✏️ Atualizar manualmente";
            const excluir = document.createElement("button"); excluir.type = "button"; excluir.textContent = "🗑️ Produto não existe mais";
            const inputWrap = document.createElement("label"); inputWrap.innerHTML = '<span style="font-size:11px;color:#94a3b8">Preço à vista R$</span>'; Object.assign(inputWrap.style, { marginTop: "9px", border: "1px solid #22d3ee", borderRadius: "10px", padding: "7px 10px", display: "flex", alignItems: "center", justifyContent: "space-between", gap: "10px", background: "#07131a" });
            const input = document.createElement("input"); input.type = "text"; input.inputMode = "decimal"; input.placeholder = "0,00"; Object.assign(input.style, { width: "100px", background: "transparent", border: "0", outline: "0", color: "#a5f3fc", fontWeight: "900", textAlign: "right", fontSize: "15px" }); inputWrap.appendChild(input);
            function pintar() { const m = escolhas[code].acao === "manual"; Object.assign(manual.style, { padding: "9px", borderRadius: "9px", border: m ? "1px solid #22d3ee" : "1px solid #334155", background: m ? "rgba(6,182,212,.14)" : "#0f172a", color: m ? "#a5f3fc" : "#94a3b8", fontWeight: "800", cursor: "pointer" }); Object.assign(excluir.style, { padding: "9px", borderRadius: "9px", border: !m ? "1px solid #fb7185" : "1px solid #334155", background: !m ? "rgba(225,29,72,.14)" : "#0f172a", color: !m ? "#fecdd3" : "#94a3b8", fontWeight: "800", cursor: "pointer" }); inputWrap.style.display = m ? "flex" : "none"; }
            manual.onclick = function () { escolhas[code].acao = "manual"; pintar(); input.focus(); };
            excluir.onclick = function () { escolhas[code].acao = "excluir"; pintar(); };
            input.oninput = function () { escolhas[code].valor = input.value; };
            linha.append(manual, excluir); card.append(linha, inputWrap); lista.appendChild(card); pintar();
        });
        box.appendChild(lista);
        const rodape = document.createElement("div"); Object.assign(rodape.style, { padding: "14px", borderTop: "1px solid #252938", display: "flex", gap: "9px" });
        const voltar = document.createElement("button"); voltar.textContent = "Voltar ao pedido"; Object.assign(voltar.style, { flex: "1", padding: "11px", borderRadius: "10px", border: "1px solid #334155", background: "#0f172a", color: "#cbd5e1", fontWeight: "800", cursor: "pointer" }); voltar.onclick = function () { ov.remove(); };
        const aplicar = document.createElement("button"); aplicar.textContent = "Aplicar decisões no Prumo"; Object.assign(aplicar.style, { flex: "1.4", padding: "11px", borderRadius: "10px", border: "0", background: "linear-gradient(135deg,#0891b2,#22d3ee)", color: "#02131a", fontWeight: "900", cursor: "pointer" });
        aplicar.onclick = function () { const manuais = [], excluidos = []; for (const code of codigos) { const e = escolhas[code], item = alvo.get(String(code)) || {}; if (e.acao === "excluir") excluidos.push(String(code)); else { const valor = Number(String(e.valor || "").replace(",", ".")); if (!(valor > 0)) { alert("Informe o preço à vista do item " + code + " ou marque que ele não existe mais."); return; } manuais.push({ code: String(code), name: item.nome || item.name || "", originalPrice: valor }); } } ov.remove(); concluir(precosLidos.concat(manuais), excluidos); };
        rodape.append(voltar, aplicar); box.appendChild(rodape); ov.appendChild(box); document.body.appendChild(ov);
    }
    function mostrarBotaoConferenciaPrecos() {
        if (!ehFramePrincipal() || !document.body) return;
        try {
            chrome.storage.local.get(["friganso_conferencia_ativa"], function (r) {
                const conf = r && r.friganso_conferencia_ativa;
                const antigo = document.getElementById("friganso-conferir-precos-btn");
                if (!conf || !conf.pronto || Date.now() - (conf.ts || 0) > 30 * 60 * 1000) { if (antigo) antigo.remove(); return; }
                if (antigo) { antigo.style.display = "block"; return; }
                const b = document.createElement("button"); b.id = "friganso-conferir-precos-btn"; b.type = "button";
                b.textContent = "💲 Atualizar preços no Prumo";
                Object.assign(b.style, { position: "fixed", right: "18px", top: "18px", zIndex: "2147483647", background: "linear-gradient(135deg,#0891b2,#06b6d4)", color: "#02131a", border: "1px solid #67e8f9", borderRadius: "12px", padding: "13px 18px", fontSize: "14px", fontWeight: "900", fontFamily: "system-ui,sans-serif", boxShadow: "0 8px 28px rgba(6,182,212,.35)", cursor: "pointer" });
                b.addEventListener("click", function () { concluirConferenciaPrecos(conf); });
                document.body.appendChild(b);
            });
        } catch (e) {}
    }

    // ---------- BOTÕES ----------
    // 🎛️ PAINEL DE AÇÕES (PC) — um quadro só, que ARRASTA e RECOLHE.
    // Antes cada botão era `position:fixed` com um `bottom` fixo (18px, 70px, 120px...). Isso tinha
    // três defeitos: a pilha ficava com BURACOS quando um botão não aparecia naquela tela (eles são
    // condicionais), dois botões disputavam a mesma altura (220px era do "ocultar" e também do
    // "Atualizar Tabela"), e não dava pra tirar da frente quando tapavam algo do SPAmov.
    // O `bottom` NÃO foi jogado fora: virou a ORDEM do botão dentro do painel, então a sequência
    // que já era pensada continua valendo, só que sem buraco.
    // ⚠️ Os ids dos botões continuam os mesmos de propósito — a fila troca o rótulo por
    // getElementById, e o "esconder tudo" varre [id^="friganso-"].
    const PAINEL_POS = "friganso_painel_pos";
    function painelAcoes() {
        let cx = document.getElementById("friganso-painel");
        if (cx) return cx.querySelector(".friganso-painel-itens");
        cx = document.createElement("div");
        cx.id = "friganso-painel";
        Object.assign(cx.style, {
            position: "fixed", right: "18px", bottom: "18px", zIndex: "2147483647",
            display: "flex", flexDirection: "column", gap: "7px", alignItems: "stretch",
            maxHeight: "82vh", fontFamily: "system-ui,sans-serif",
        });
        // posição salva de quando o vendedor arrastou
        try {
            const salvo = JSON.parse(window.localStorage.getItem(PAINEL_POS) || "null");
            if (salvo && typeof salvo.left === "number") {
                cx.style.left = salvo.left + "px"; cx.style.top = salvo.top + "px";
                cx.style.right = "auto"; cx.style.bottom = "auto";
            }
        } catch (e) {}

        const topo = document.createElement("div");
        Object.assign(topo.style, {
            display: "flex", alignItems: "center", gap: "8px", cursor: "move", userSelect: "none",
            background: "linear-gradient(110deg,#211a37,#12232b)", color: "#fff",
            border: "1px solid rgba(124,108,255,.25)", borderRadius: "11px", padding: "9px 11px",
            font: "800 12px system-ui,sans-serif", boxShadow: "0 6px 20px rgba(0,0,0,.3)",
        });
        const rotulo = document.createElement("span");
        rotulo.textContent = "✦ PRUMO"; rotulo.style.flex = "1";
        const recolher = document.createElement("button");
        recolher.type = "button"; recolher.textContent = "–"; recolher.title = "Recolher";
        Object.assign(recolher.style, { background: "rgba(255,255,255,.12)", color: "#fff", border: "none", borderRadius: "7px", width: "24px", height: "24px", cursor: "pointer", font: "800 14px system-ui", lineHeight: "1" });
        topo.append(rotulo, recolher);

        const itens = document.createElement("div");
        itens.className = "friganso-painel-itens";
        Object.assign(itens.style, { display: "flex", flexDirection: "column", gap: "7px", overflowY: "auto", paddingRight: "2px" });

        recolher.addEventListener("click", function (ev) {
            ev.stopPropagation();
            const fechado = itens.style.display === "none";
            itens.style.display = fechado ? "flex" : "none";
            recolher.textContent = fechado ? "–" : "+";
            rotulo.textContent = fechado ? "✦ PRUMO" : "✦ PRUMO · " + itens.children.length;
        });

        // arrastar pelo cabeçalho (mouse e toque)
        let arrastando = false, dx = 0, dy = 0;
        const pegar = (e) => {
            const t = e.touches ? e.touches[0] : e;
            const r = cx.getBoundingClientRect();
            arrastando = true; dx = t.clientX - r.left; dy = t.clientY - r.top;
            cx.style.left = r.left + "px"; cx.style.top = r.top + "px";
            cx.style.right = "auto"; cx.style.bottom = "auto";
        };
        const mover = (e) => {
            if (!arrastando) return;
            const t = e.touches ? e.touches[0] : e;
            // não deixa sumir pra fora da janela — arrastar pra fora e não achar mais é pior que não arrastar
            const larg = cx.offsetWidth, alt = cx.offsetHeight;
            const x = Math.max(4, Math.min(window.innerWidth - larg - 4, t.clientX - dx));
            const y = Math.max(4, Math.min(window.innerHeight - alt - 4, t.clientY - dy));
            cx.style.left = x + "px"; cx.style.top = y + "px";
            if (e.cancelable) e.preventDefault();
        };
        const soltar = () => {
            if (!arrastando) return;
            arrastando = false;
            try { window.localStorage.setItem(PAINEL_POS, JSON.stringify({ left: parseInt(cx.style.left, 10) || 0, top: parseInt(cx.style.top, 10) || 0 })); } catch (e) {}
        };
        topo.addEventListener("mousedown", pegar);
        topo.addEventListener("touchstart", pegar, { passive: true });
        document.addEventListener("mousemove", mover);
        document.addEventListener("touchmove", mover, { passive: false });
        document.addEventListener("mouseup", soltar);
        document.addEventListener("touchend", soltar);

        cx.append(topo, itens);
        document.body.appendChild(cx);
        return itens;
    }

    function botao(id, texto, cor, bottom, onClick) {
        if (document.getElementById(id)) return;
        const b = document.createElement("button");
        b.id = id; b.type = "button"; b.textContent = texto;
        Object.assign(b.style, { background: cor, color: "#fff", border: "none", borderRadius: "12px", padding: "12px 18px", fontSize: "14px", fontWeight: "bold", fontFamily: "system-ui,sans-serif", boxShadow: "0 6px 20px rgba(0,0,0,0.3)", cursor: "pointer", textAlign: "left", whiteSpace: "nowrap" });
        // o antigo `bottom` vira a ordem dentro do painel: mantém a sequência já pensada, sem buraco
        b.style.order = String(parseInt(bottom, 10) || 0);
        // No navegador Android essas ações continuam disponíveis para a automação e para a barra
        // nativa, mas não ficam espalhadas por cima do site antigo.
        if (ehNavegadorAndroid()) { b.style.display = 'none'; document.body.appendChild(b); return; }
        b.addEventListener("click", onClick);
        painelAcoes().appendChild(b);
    }

    // 👁️ Botão mestre pra esconder/mostrar TODOS os elementos da extensão de uma vez — às vezes eles
    // ficam em cima de algo da tela do SPAmov que o vendedor precisa ler. Usa "visibility" (não
    // "display") de propósito: assim não bagunça o estado próprio de cada um (ex.: o painel de log
    // continua fechado se já estava fechado, mesmo depois de mostrar tudo de novo).
    // Fica na MESMA pilha dos outros botões (canto inferior direito), não separado — por isso não usa
    // o helper botao() (que não deixa trocar o texto depois de criado, e aqui precisa alternar o rótulo).
    function criarBotaoOcultar(bottom) {
        if (document.getElementById("friganso-toggle-btn")) return;
        const btn = document.createElement("button");
        btn.id = "friganso-toggle-btn"; btn.type = "button"; btn.textContent = "👁️ Esconder botões";
        Object.assign(btn.style, { background: "#334155", color: "#fff", border: "none", borderRadius: "12px", padding: "12px 18px", fontSize: "14px", fontWeight: "bold", fontFamily: "system-ui,sans-serif", boxShadow: "0 6px 20px rgba(0,0,0,0.3)", cursor: "pointer", textAlign: "left", whiteSpace: "nowrap" });
        btn.style.order = String(parseInt(bottom, 10) || 0);
        let escondido = false;
        btn.addEventListener("click", function () {
            escondido = !escondido;
            document.querySelectorAll('[id^="friganso-"]').forEach(function (el) {
                // ⚠️ O painel NÃO pode se esconder: este botão mora dentro dele, e esconder os dois
                // juntos deixaria o vendedor sem nenhum jeito de trazer de volta.
                if (el.id === "friganso-toggle-btn" || el.id === "friganso-painel") return;
                if (el.closest && el.closest("#friganso-painel")) return;
                el.style.visibility = escondido ? "hidden" : "";
            });
            btn.textContent = escondido ? "👁️ Mostrar avisos" : "👁️ Esconder avisos";
        });
        painelAcoes().appendChild(btn);
    }

    const temLeitura = temPedidoLeitura(montarPedidoLeitura());

    if (ehFramePrincipal()) {
        botao("friganso-lancar-btn", "🚀 Lançar pedido", "#15803d", "120px", abrirPopupFila);
        botao("friganso-cancelar-btn", "⏹ Cancelar lançamento", "#64748b", "70px", cancelarLancamento);
        // 🪜 Etapas: retomar o lançamento de um ponto específico quando o processo se perde no meio
        botao("friganso-etapas-btn", "🪜 Etapas", "#b45309", "320px", abrirPopupEtapas);
        criarBotaoOcultar("220px");
    }
    // 📋 O botão principal agora SOMA à fila em vez de pular direto pro app — o vendedor lança vários
    // pedidos seguidos e só vai pro app no fim. Segurar SHIFT ao clicar mantém o jeito antigo (vai
    // direto pro app com esse pedido só), pra quando for um pedido avulso.
    if (temLeitura) {
        botao("friganso-erp-btn", "📋 Somar pedido à fila", "#e11d48", "18px", function (ev) {
            if (ev && ev.shiftKey) { enviarParaApp(); return; }
            somarPedidoNaFila();
        });
        botao("friganso-fila-btn", "✅ Finalizar e abrir o app", "#15803d", "270px", finalizarFila);
        const bFim = document.getElementById("friganso-fila-btn");
        if (bFim) bFim.style.display = "none";
        lerFila(atualizarRotulosFila);
    }
    // 🔍 "Ler Página": disponível em QUALQUER tela do SPAmov (não só pedido), pra usar como ferramenta
    // de exploração — ex.: Lista de Preços, Histórico, etc. — na hora de criar uma automação nova.
    botao("friganso-diag-btn", "🔍 Ler Página", "#0f172a", "170px", gerarDiagnostico);
    // 📥 Atualizar Tabela: só na tela "Lista de Preços" — lê o catálogo inteiro direto da tela
    // (sem precisar de PDF) e manda pro site, que atualiza a Tabela de Preços sozinho.
    if (ehTelaListaPrecos()) botao("friganso-tabela-btn", ehNavegadorAndroid() ? "📥 Enviar tabela ao aplicativo" : "📥 Atualizar Tabela do Site", "#7c3aed", "220px", enviarTabelaParaApp);
    // 📊 Relatório de Vendas: só na tela que lista pedidos por SPAMOV com peso embarcado/faturado reais
    // — lê tudo e manda pro site, que usa isso pra corrigir o faturamento real (não a estimativa).
    if (ehTelaRelatorioVendas()) botao("friganso-vendas-btn", "📊 Enviar Relatório de Vendas", "#0891b2", "270px", enviarRelatorioVendasParaApp);
    // 👥 Clientes: só na tela "Procura de Pessoas" — lê o cadastro completo (com CNPJ, endereço,
    // telefone e limite/saldo de crédito) e manda pro site. Usa o mesmo 270px do relatório de vendas
    // sem risco de conflito: as duas telas são diferentes, nunca aparecem juntas.
    if (ehTelaClientes()) botao("friganso-clientes-btn", "👥 Atualizar Clientes do Site", "#0d9488", "270px", enviarClientesParaApp);

    instalarBarraAndroid();

    // Mostra o log salvo (passo a passo que sobrevive aos recarregamentos)
    if (ehFramePrincipal()) mostrarLogSalvo();
    if (ehFramePrincipal()) mostrarBotaoConferenciaPrecos();
    // Retoma automaticamente um lançamento em andamento (após cada reload do site)
    if (ehFramePrincipal()) processarRun();
    // 👀 Vigia: confere o lançamento a cada 4s, mesmo se a página não recarregar (internet ruim)
    setInterval(vigiarRun, 4000);
    // Login automático (se solicitado pelo Debug e estivermos na tela de login)
    tentarLogin();
    // Após logar, navega: SPA mov -> VENDAS - VENDEDOR
    tentarNavegarVendas();
    // ⚡ Se houver pedido pendente "automático", dispara o lançamento ao chegar na tela de vendas
    tentarIniciarAuto();

    // ═══════════════════════════════════════════════════════════════════════════════════
    // 🤖 ZAP AUTOMÁTICO no WhatsApp Web (2026-08-13)
    // Faz no SITE o que o programa de PC já fazia: manda a campanha inteira sozinho.
    //
    // Por que precisa da extensão: um site NÃO consegue clicar dentro do web.whatsapp.com
    // (origens diferentes, o navegador proíbe). O programa de PC dribla isso com uma <webview>
    // que ele controla. A extensão dribla porque roda DENTRO da página do WhatsApp.
    //
    // Navega pela interface já aberta: Nova conversa → pesquisa do número → mensagem → Enviar.
    // Nenhum contato usa /send?phone e a página do WhatsApp permanece carregada durante a fila.
    // ═══════════════════════════════════════════════════════════════════════════════════
    function iniciarZapAuto() {
        if (window.__prumoZapAutoIniciado) return;
        window.__prumoZapAutoIniciado = true;
        const CHAVE = "friganso_zap_campanha";
        const VALIDADE = 60 * 60 * 1000;
        const ESPERA_INTERFACE = 90;
        const soDig = (s) => String(s || "").replace(/\D/g, "");
        const dormir = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
        const ler = (cb) => { try { chrome.storage.local.get([CHAVE], (r) => cb((r && r[CHAVE]) || null)); } catch (e) { cb(null); } };
        const gravar = (c, cb) => { try { const o = {}; o[CHAVE] = c; chrome.storage.local.set(o, () => cb && cb()); } catch (e) { cb && cb(); } };
        const limpar = () => { try { chrome.storage.local.remove(CHAVE); } catch (e) {} };

        function visivel(el) {
            if (!el || !el.isConnected) return false;
            const r = el.getBoundingClientRect(), s = getComputedStyle(el);
            return r.width > 5 && r.height > 5 && s.display !== "none" && s.visibility !== "hidden";
        }
        async function esperarAte(fn, tentativas) {
            const max = tentativas || ESPERA_INTERFACE;
            for (let i = 0; i < max; i++) {
                try { const achou = fn(); if (achou) return achou; } catch (e) {}
                await dormir(250);
            }
            return null;
        }
        function clicavel(el) {
            if (!el) return null;
            return el.closest('[role="listitem"], [role="button"], button, [tabindex="0"], [tabindex="-1"], [data-testid="cell-frame-container"]') || el;
        }
        function acharNovaConversa() {
            const direto = document.querySelector('button[aria-label="Nova conversa"], button[aria-label="New chat"], [title="Nova conversa"], [title="New chat"]');
            if (visivel(direto)) return direto;
            const icone = document.querySelector('span[data-icon="new-chat-outline"], span[data-icon="new-chat-filled"], [data-testid="new-chat-button"]');
            const botao = clicavel(icone);
            return visivel(botao) ? botao : null;
        }
        function caixasDePesquisa() {
            return Array.from(document.querySelectorAll([
                'div[contenteditable="true"][data-tab="3"]',
                'div[contenteditable="true"][role="textbox"][aria-label*="pesqui" i]',
                'div[contenteditable="true"][role="textbox"][aria-label*="search" i]',
                'div[contenteditable="true"][role="textbox"][aria-placeholder*="pesqui" i]',
                'div[contenteditable="true"][role="textbox"][aria-placeholder*="search" i]',
                'div[contenteditable="true"][role="textbox"]'
            ].join(','))).filter((el) => visivel(el) && !el.closest('footer') && !el.closest('#friganso-zap-painel'));
        }
        function escreverNoEditor(el, texto) {
            if (!el) return false;
            el.focus();
            try {
                document.execCommand("selectAll", false, null);
                document.execCommand("delete", false, null);
                if (String(el.innerText || el.textContent || "").trim()) el.textContent = "";
                document.execCommand("insertText", false, String(texto || ""));
            } catch (e) {}
            if (String(el.innerText || el.textContent || "").trim() !== String(texto || "").trim()) el.textContent = String(texto || "");
            try { el.dispatchEvent(new InputEvent("input", { bubbles: true, inputType: "insertText", data: String(texto || "") })); }
            catch (e) { el.dispatchEvent(new Event("input", { bubbles: true })); }
            return true;
        }
        function acharLinhaDoNumero(telefone) {
            const alvo = soDig(telefone).slice(-8);
            if (!alvo) return null;
            const seletores = '[role="listitem"], [data-testid="cell-frame-container"], [role="button"], [tabindex="0"] span[title], [tabindex="-1"] span[title], span[title]';
            const encontrados = [];
            document.querySelectorAll(seletores).forEach((el) => {
                if (!visivel(el) || el.isContentEditable || el.closest('[contenteditable="true"]') || el.closest('#friganso-zap-painel') || el.closest('footer')) return;
                const texto = soDig((el.innerText || el.textContent || "") + " " + (el.getAttribute("title") || ""));
                if (!texto.includes(alvo)) return;
                const linha = clicavel(el);
                if (visivel(linha)) encontrados.push(linha);
            });
            encontrados.sort((a, b) => {
                const ra = a.getBoundingClientRect(), rb = b.getBoundingClientRect();
                return (ra.width * ra.height) - (rb.width * rb.height);
            });
            return encontrados[0] || null;
        }
        function acharEditorMensagem() {
            const candidatos = Array.from(document.querySelectorAll([
                'footer div[contenteditable="true"][role="textbox"]',
                'div[contenteditable="true"][role="textbox"][aria-label*="mensagem" i]',
                'div[contenteditable="true"][role="textbox"][aria-label*="message" i]',
                'div[contenteditable="true"][data-tab="10"]'
            ].join(','))).filter((el) => visivel(el) && !el.closest('#friganso-zap-painel'));
            return candidatos[candidatos.length - 1] || null;
        }
        function acharBotaoEnviar() {
            const alvo = document.querySelector('button[aria-label="Enviar"], button[aria-label="Send"], span[data-icon="send"], [data-testid="send"]');
            const botao = clicavel(alvo);
            return visivel(botao) ? botao : null;
        }
        async function abrirConversa(item) {
            const telefone = soDig(item.telefone);
            if (!telefone) return null;
            const nova = acharNovaConversa();
            if (nova) { try { nova.click(); } catch (e) {} await dormir(300); }
            const busca = await esperarAte(() => { const caixas = caixasDePesquisa(); return caixas[caixas.length - 1] || null; });
            if (!busca) return null;
            escreverNoEditor(busca, telefone);
            const linha = await esperarAte(() => acharLinhaDoNumero(telefone));
            if (!linha) return null;
            try { linha.click(); } catch (e) { return null; }
            await dormir(700);
            return esperarAte(() => acharEditorMensagem());
        }
        async function enviarItem(item) {
            const editor = await abrirConversa(item);
            if (!editor) return false;
            escreverNoEditor(editor, item.mensagem || "");
            const botao = await esperarAte(() => acharBotaoEnviar(), 60);
            if (!botao) return false;
            try { botao.click(); return true; } catch (e) { return false; }
        }

        let painel = null;
        function montarPainel() {
            if (painel && painel.isConnected) return painel;
            painel = document.createElement("div");
            painel.id = "friganso-zap-painel";
            painel.style.cssText = [
                "position:fixed", "right:16px", "bottom:16px", "z-index:2147483647", "width:290px",
                "background:#0f172a", "color:#fff", "border-radius:16px", "box-shadow:0 10px 40px rgba(0,0,0,.45)",
                "padding:14px", "font-family:system-ui,-apple-system,Segoe UI,Roboto,sans-serif", "font-size:13px"
            ].join(";");
            document.documentElement.appendChild(painel);
            return painel;
        }
        function pintar(c, aviso) {
            const p = montarPainel(), total = c.itens.length;
            const feitos = c.itens.filter((i) => i.status).length;
            const ok = c.itens.filter((i) => i.status === "enviado").length;
            const falhas = c.itens.filter((i) => i.status === "falhou").length;
            const atual = c.itens[c.idx], pct = total ? Math.round((feitos / total) * 100) : 0;
            p.innerHTML =
                '<div style="display:flex;align-items:center;gap:8px;margin-bottom:8px"><span style="font-size:18px">✦</span><b style="flex:1">Prumo — Disparo</b><span id="frig-x" style="cursor:pointer;opacity:.6;font-size:16px" title="Fechar e cancelar">✕</span></div>' +
                '<div style="background:#1e293b;border-radius:999px;height:6px;overflow:hidden;margin-bottom:6px"><div style="background:linear-gradient(90deg,#7c6cff,#22d3ee);height:100%;width:' + pct + '%;transition:width .3s"></div></div>' +
                '<div style="opacity:.75;margin-bottom:8px">' + feitos + " de " + total + " · ✅ " + ok + (falhas ? " · ⚠️ " + falhas : "") + "</div>" +
                (atual && c.rodando ? '<div style="background:#1e293b;border-radius:10px;padding:8px;margin-bottom:8px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">➡️ ' + (atual.nome || atual.telefone) + "</div>" : "") +
                (aviso ? '<div style="background:#7c2d12;border-radius:10px;padding:8px;margin-bottom:8px">' + aviso + "</div>" : "") +
                '<button id="frig-btn" style="width:100%;border:0;border-radius:10px;padding:10px;font-weight:700;cursor:pointer;background:' + (c.rodando ? "#dc2626" : "#7c6cff") + ';color:#fff">' + (c.rodando ? "⏸ Pausar" : (feitos ? "▶ Continuar" : "▶ Iniciar envio")) + "</button>" +
                '<div style="opacity:.55;font-size:11px;margin-top:8px;line-height:1.4">Sem recarregar: o Prumo pesquisa e abre cada conversa dentro desta tela. Respiro: ' + Math.max(2, c.respiro || 8) + "s.</div>";
            p.querySelector("#frig-x").onclick = () => { limpar(); p.remove(); painel = null; };
            p.querySelector("#frig-btn").onclick = () => { c.rodando = !c.rodando; gravar(c, () => { pintar(c); if (c.rodando) prosseguir(c); }); };
        }
        function finalizarItem(c, item, ok) {
            if (!c.itens[c.idx]) return;
            c.itens[c.idx].status = ok ? "enviado" : "falhou";
            c.idx++;
            gravar(c, () => {
                pintar(c, ok ? null : "⚠️ Não encontrei ou não consegui enviar para " + (item.nome || item.telefone) + ". Pulei sem recarregar.");
                if (!c.itens[c.idx]) { c.rodando = false; gravar(c, () => pintar(c, "🎉 Campanha concluída!")); return; }
                setTimeout(() => { if (c.rodando) prosseguir(c); }, Math.max(2, c.respiro || 8) * 1000);
            });
        }
        async function prosseguir(c) {
            if (!c.rodando || c.processando) return;
            const item = c.itens[c.idx];
            if (!item) { c.rodando = false; gravar(c, () => pintar(c, "🎉 Campanha concluída!")); return; }
            c.processando = true; gravar(c); pintar(c, "🔎 Abrindo a conversa sem recarregar o WhatsApp…");
            const ok = await enviarItem(item);
            c.processando = false;
            finalizarItem(c, item, ok);
        }
        function arrancar() {
            ler((c) => {
                if (!c || !Array.isArray(c.itens) || !c.itens.length) return;
                if (Date.now() - (c.ts || 0) > VALIDADE) { limpar(); return; }
                c.processando = false;
                pintar(c);
                if (c.rodando) prosseguir(c);
            });
        }
        if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", () => setTimeout(arrancar, 1000), { once: true });
        else setTimeout(arrancar, 1000);
    }
})();
